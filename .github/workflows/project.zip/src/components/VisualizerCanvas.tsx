import React, { useEffect, useRef, useState, useCallback, useImperativeHandle, forwardRef } from 'react';
import {
  WaveformConfig,
  BackgroundConfig,
  CenterArtConfig,
  TextOverlayConfig,
  EffectsConfig,
  AspectRatioType,
} from '../types';
import { audioEngine } from '../utils/audioEngine';
import { COLOR_PRESETS } from '../utils/presets';

interface Particle {
  x: number;
  y: number;
  size: number;
  speedX: number;
  speedY: number;
  alpha: number;
  color: string;
  angle: number;
  distance: number;
  orbitSpeed: number;
}

export interface VisualizerCanvasHandle {
  captureSnapshot: (waveformOnly?: boolean, resolutionScale?: number) => string;
  startVideoRecording: (
    onProgress?: (seconds: number) => void,
    options?: {
      quality?: '4k' | '1080p' | '720p';
      fps?: 60 | 30;
      bitrate?: number;
      format?: 'webm' | 'mp4';
    }
  ) => Promise<void>;
  stopVideoRecording: () => Promise<Blob | null>;
  isRecording: boolean;
}

interface VisualizerCanvasProps {
  waveform: WaveformConfig;
  background: BackgroundConfig;
  centerArt: CenterArtConfig;
  textOverlay: TextOverlayConfig;
  effects: EffectsConfig;
  aspectRatio: AspectRatioType;
  currentTime: number;
  duration: number;
  isPlaying: boolean;
  onCanvasClick?: () => void;
  onDropAudio?: (file: File) => void;
  onDropImage?: (file: File) => void;
  onDirectDownloadPng?: () => void;
  onDirectRecordVideo?: () => void;
  lang?: 'en' | 'ka';
}

export const VisualizerCanvas = forwardRef<VisualizerCanvasHandle, VisualizerCanvasProps>(
  (
    {
      waveform,
      background,
      centerArt,
      textOverlay,
      effects,
      aspectRatio,
      currentTime,
      duration,
      isPlaying,
      onCanvasClick,
      onDropAudio,
      onDropImage,
      onDirectDownloadPng,
      onDirectRecordVideo,
      lang = 'ka',
    },
    ref
  ) => {
    const canvasRef = useRef<HTMLCanvasElement | null>(null);
    const containerRef = useRef<HTMLDivElement | null>(null);
    const [isDraggingOver, setIsDraggingOver] = useState<boolean>(false);
    const [dragKind, setDragKind] = useState<'audio' | 'image' | 'generic'>('generic');

    // Audio Analysis Buffers
    const freqDataRef = useRef<Uint8Array>(new Uint8Array(512));
    const timeDataRef = useRef<Uint8Array>(new Uint8Array(512));
    const smoothFreqRef = useRef<Float32Array>(new Float32Array(512));
    const peakBarsRef = useRef<Float32Array>(new Float32Array(512));

    // Images cache
    const bgImageRef = useRef<HTMLImageElement | null>(null);
    const centerImageRef = useRef<HTMLImageElement | null>(null);

    // Dynamic animation states
    const rotationAngleRef = useRef<number>(0);
    const bassPulseRef = useRef<number>(0);
    const particlesRef = useRef<Particle[]>([]);
    const animationFrameRef = useRef<number | null>(null);

    // Video Recording state
    const mediaRecorderRef = useRef<MediaRecorder | null>(null);
    const recordedChunksRef = useRef<Blob[]>([]);
    const [isRecording, setIsRecording] = useState<boolean>(false);
    const recordingTimerRef = useRef<number | null>(null);
    const recordStartTimeRef = useRef<number>(0);

    // Aspect ratio dimensions
    const getCanvasDimensions = () => {
      switch (aspectRatio) {
        case '16:9':
          return { width: 1920, height: 1080 };
        case '9:16':
          return { width: 1080, height: 1920 };
        case '1:1':
          return { width: 1080, height: 1080 };
        case '4:3':
          return { width: 1440, height: 1080 };
        default:
          return { width: 1920, height: 1080 };
      }
    };

    // Load Background Image
    useEffect(() => {
      if (background.type === 'image' && background.imageUrl) {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.src = background.imageUrl;
        img.onload = () => {
          bgImageRef.current = img;
        };
      } else {
        bgImageRef.current = null;
      }
    }, [background.imageUrl, background.type]);

    // Load Center Art Image
    useEffect(() => {
      if (centerArt.imageUrl) {
        const img = new Image();
        img.crossOrigin = 'anonymous';
        img.src = centerArt.imageUrl;
        img.onload = () => {
          centerImageRef.current = img;
        };
      } else {
        centerImageRef.current = null;
      }
    }, [centerArt.imageUrl]);

    // Initialize Particles
    useEffect(() => {
      const count = effects.particleCount;
      const { width, height } = getCanvasDimensions();
      const particles: Particle[] = [];
      const colors =
        waveform.colorPreset === 'custom'
          ? waveform.customColors
          : COLOR_PRESETS[waveform.colorPreset]?.colors || ['#06b6d4', '#ec4899'];

      for (let i = 0; i < count; i++) {
        const angle = Math.random() * Math.PI * 2;
        const distance = Math.random() * Math.min(width, height) * 0.6;
        particles.push({
          x: Math.random() * width,
          y: Math.random() * height,
          size: Math.random() * 3 + 1,
          speedX: (Math.random() - 0.5) * effects.particleSpeed,
          speedY: (Math.random() - 0.5) * effects.particleSpeed,
          alpha: Math.random() * 0.7 + 0.3,
          color: colors[Math.floor(Math.random() * colors.length)],
          angle,
          distance,
          orbitSpeed: (Math.random() * 0.02 + 0.005) * (Math.random() > 0.5 ? 1 : -1),
        });
      }
      particlesRef.current = particles;
    }, [effects.particleCount, effects.particleSpeed, waveform.colorPreset, waveform.customColors, aspectRatio]);

    // Formatting helper
    const formatTime = (secs: number) => {
      if (isNaN(secs) || secs < 0) return '00:00';
      const m = Math.floor(secs / 60);
      const s = Math.floor(secs % 60);
      return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
    };

    // Color gradient resolver
    const getColors = useCallback(() => {
      if (waveform.colorPreset === 'custom' && waveform.customColors.length > 0) {
        return waveform.customColors;
      }
      return COLOR_PRESETS[waveform.colorPreset]?.colors || ['#06b6d4', '#3b82f6', '#ec4899'];
    }, [waveform.colorPreset, waveform.customColors]);

    const getGlowColor = useCallback(() => {
      if (waveform.colorPreset === 'custom' && waveform.customColors.length > 0) {
        return waveform.customColors[0];
      }
      return COLOR_PRESETS[waveform.colorPreset]?.glowColor || '#06b6d4';
    }, [waveform.colorPreset, waveform.customColors]);

    // Main Draw Function
    const renderFrame = useCallback(() => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const ctx = canvas.getContext('2d', { alpha: true });
      if (!ctx) return;

      const { width, height } = getCanvasDimensions();
      if (canvas.width !== width || canvas.height !== height) {
        canvas.width = width;
        canvas.height = height;
      }

      // 1. Fetch audio data
      const analyser = audioEngine.getAnalyser();
      if (analyser) {
        if (freqDataRef.current.length !== analyser.frequencyBinCount) {
          freqDataRef.current = new Uint8Array(analyser.frequencyBinCount);
          timeDataRef.current = new Uint8Array(analyser.frequencyBinCount);
          smoothFreqRef.current = new Float32Array(analyser.frequencyBinCount);
          peakBarsRef.current = new Float32Array(analyser.frequencyBinCount);
        }
        audioEngine.getFrequencyData(freqDataRef.current);
        audioEngine.getTimeDomainData(timeDataRef.current);
      }

      // Smooth frequencies and detect bass
      const freqData = freqDataRef.current;
      const smoothFreq = smoothFreqRef.current;
      const peakBars = peakBarsRef.current;
      const smoothing = waveform.smoothing;

      let bassEnergy = 0;
      let totalEnergy = 0;
      const bassBins = Math.floor(freqData.length * 0.08);

      for (let i = 0; i < freqData.length; i++) {
        // Fallback simulation when idle or playing
        let rawVal = freqData[i];
        if (!isPlaying && rawVal === 0) {
          const t = performance.now() * 0.002;
          rawVal = Math.floor((Math.sin(t + i * 0.1) * 0.5 + 0.5) * 40 + Math.sin(t * 2 + i * 0.05) * 20);
        }

        smoothFreq[i] = smoothFreq[i] * smoothing + rawVal * (1 - smoothing);
        
        // Peak hold animation
        if (smoothFreq[i] > peakBars[i]) {
          peakBars[i] = smoothFreq[i];
        } else {
          peakBars[i] = Math.max(0, peakBars[i] - 1.2);
        }

        if (i < bassBins) {
          bassEnergy += rawVal;
        }
        totalEnergy += rawVal;
      }

      const avgBass = bassBins > 0 ? bassEnergy / bassBins / 255 : 0;
      const avgOverall = freqData.length > 0 ? totalEnergy / freqData.length / 255 : 0;

      // Update bass pulse
      bassPulseRef.current = bassPulseRef.current * 0.85 + avgBass * 0.15;
      const currentBassPulse = bassPulseRef.current;

      // Rotation for center art
      if (centerArt.spinWithAudio) {
        rotationAngleRef.current += (0.005 + avgBass * 0.02) * (centerArt.rotationSpeed || 1);
      }

      ctx.save();
      ctx.clearRect(0, 0, width, height);

      // 2. Render Background
      ctx.save();
      const bgScale = 1 + (background.pulseWithBass ? currentBassPulse * background.pulseStrength : 0);
      ctx.translate(width / 2, height / 2);
      ctx.scale(bgScale, bgScale);
      ctx.translate(-width / 2, -height / 2);

      if (background.type === 'image' && bgImageRef.current && bgImageRef.current.complete) {
        if (background.blur > 0) {
          ctx.filter = `blur(${background.blur}px)`;
        }
        const img = bgImageRef.current;
        const imgRatio = img.width / img.height;
        const canvasRatio = width / height;
        let dw = width;
        let dh = height;
        let dx = 0;
        let dy = 0;

        if (canvasRatio > imgRatio) {
          dh = width / imgRatio;
          dy = (height - dh) / 2;
        } else {
          dw = height * imgRatio;
          dx = (width - dw) / 2;
        }

        // Slight margin for blur overflow
        ctx.drawImage(img, dx - 20, dy - 20, dw + 40, dh + 40);
        ctx.filter = 'none';
      } else if (background.type === 'gradient') {
        const angleRad = ((background.gradientAngle || 135) * Math.PI) / 180;
        const x2 = width / 2 + (Math.cos(angleRad) * width) / 2;
        const y2 = height / 2 + (Math.sin(angleRad) * height) / 2;
        const x1 = width / 2 - (Math.cos(angleRad) * width) / 2;
        const y1 = height / 2 - (Math.sin(angleRad) * height) / 2;
        const grad = ctx.createLinearGradient(x1, y1, x2, y2);
        grad.addColorStop(0, background.gradientColors[0] || '#0f172a');
        grad.addColorStop(1, background.gradientColors[1] || '#020617');
        ctx.fillStyle = grad;
        ctx.fillRect(0, 0, width, height);
      } else {
        ctx.fillStyle = background.solidColor || '#030712';
        ctx.fillRect(0, 0, width, height);
      }
      ctx.restore();

      // Background Dim Overlay
      if (background.dim > 0) {
        ctx.fillStyle = `rgba(0, 0, 0, ${background.dim})`;
        ctx.fillRect(0, 0, width, height);
      }

      // 3. Effects: Beat Shockwave
      if (effects.bassShockwave && avgBass > 0.45) {
        ctx.save();
        const shockRadius = (avgBass - 0.4) * Math.min(width, height) * 1.5;
        const shockGrad = ctx.createRadialGradient(
          width / 2,
          height * waveform.positionY,
          10,
          width / 2,
          height * waveform.positionY,
          shockRadius
        );
        shockGrad.addColorStop(0, 'rgba(255, 255, 255, 0)');
        shockGrad.addColorStop(0.8, `${getGlowColor()}33`);
        shockGrad.addColorStop(1, 'rgba(255, 255, 255, 0)');
        ctx.fillStyle = shockGrad;
        ctx.beginPath();
        ctx.arc(width / 2, height * waveform.positionY, shockRadius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }

      // 4. Effects: Particles
      if (effects.particlesEnabled) {
        ctx.save();
        const particles = particlesRef.current;
        const boost = 1 + avgBass * 3;

        for (let i = 0; i < particles.length; i++) {
          const p = particles[i];
          if (effects.particleType === 'stars') {
            p.y -= p.speedY * boost;
            p.x += p.speedX * boost;
            if (p.y < 0) p.y = height;
            if (p.y > height) p.y = 0;
            if (p.x < 0) p.x = width;
            if (p.x > width) p.x = 0;

            ctx.fillStyle = p.color;
            ctx.globalAlpha = Math.min(1, p.alpha * (0.6 + avgOverall * 0.8));
            ctx.shadowBlur = waveform.glowIntensity > 0 ? 8 : 0;
            ctx.shadowColor = p.color;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size * (1 + avgBass * 0.8), 0, Math.PI * 2);
            ctx.fill();
          } else if (effects.particleType === 'fireflies') {
            p.angle += 0.03;
            p.x += Math.cos(p.angle) * 1.2 * boost;
            p.y += (Math.sin(p.angle) - 0.5) * 1.5 * boost;
            if (p.y < 0) p.y = height;
            if (p.x < 0) p.x = width;
            if (p.x > width) p.x = 0;

            ctx.fillStyle = p.color;
            ctx.globalAlpha = Math.min(1, p.alpha * (0.5 + Math.sin(p.angle * 2) * 0.3 + avgBass * 0.4));
            ctx.shadowBlur = 12;
            ctx.shadowColor = p.color;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size * 1.5, 0, Math.PI * 2);
            ctx.fill();
          } else {
            // Dust / Bubbles
            p.y -= Math.abs(p.speedY) * 0.8 * boost;
            if (p.y < 0) p.y = height;
            ctx.fillStyle = p.color;
            ctx.globalAlpha = p.alpha * 0.5;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
            ctx.fill();
          }
        }
        ctx.restore();
      }

      // 5. Render Center Artwork / Badge (if shape !== 'none' and circular/vinyl modes)
      const centerX = width / 2;
      const centerY = height * (waveform.positionY || 0.5);
      const minDim = Math.min(width, height);
      const baseCenterSize = minDim * (centerArt.size || 0.25);
      const activeCenterScale = 1 + (centerArt.pulseScale || 0.08) * avgBass;
      const centerRadius = (baseCenterSize * activeCenterScale) / 2;

      const renderCenterArt = () => {
        if (centerArt.shape === 'none') return;

        ctx.save();
        ctx.translate(centerX, centerY);
        ctx.rotate(rotationAngleRef.current);

        // Glow
        if (waveform.glowIntensity > 0) {
          ctx.shadowBlur = waveform.glowIntensity * 1.2;
          ctx.shadowColor = centerArt.borderColor || getGlowColor();
        }

        // Clip shape
        ctx.beginPath();
        if (centerArt.shape === 'circle' || centerArt.shape === 'vinyl') {
          ctx.arc(0, 0, centerRadius, 0, Math.PI * 2);
        } else if (centerArt.shape === 'rounded') {
          const r = centerRadius * 0.25;
          const s = centerRadius;
          ctx.roundRect(-s, -s, s * 2, s * 2, r);
        } else {
          // square
          const s = centerRadius;
          ctx.rect(-s, -s, s * 2, s * 2);
        }
        ctx.closePath();

        // Vinyl Grooves effect
        if (centerArt.shape === 'vinyl') {
          ctx.fillStyle = '#0a0a0c';
          ctx.fill();

          // Vinyl concentric grooves
          ctx.lineWidth = 1;
          for (let g = centerRadius * 0.35; g < centerRadius * 0.95; g += 4) {
            ctx.strokeStyle = g % 8 === 0 ? 'rgba(255, 255, 255, 0.07)' : 'rgba(0, 0, 0, 0.4)';
            ctx.beginPath();
            ctx.arc(0, 0, g, 0, Math.PI * 2);
            ctx.stroke();
          }

          // Center record sticker badge
          const stickerRadius = centerRadius * 0.36;
          ctx.save();
          ctx.beginPath();
          ctx.arc(0, 0, stickerRadius, 0, Math.PI * 2);
          ctx.clip();
          if (centerImageRef.current && centerImageRef.current.complete) {
            ctx.drawImage(
              centerImageRef.current,
              -stickerRadius,
              -stickerRadius,
              stickerRadius * 2,
              stickerRadius * 2
            );
          } else {
            ctx.fillStyle = getGlowColor();
            ctx.fill();
          }
          ctx.restore();

          // Center spindle hole
          ctx.fillStyle = '#000000';
          ctx.beginPath();
          ctx.arc(0, 0, 6, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.4)';
          ctx.lineWidth = 1.5;
          ctx.stroke();
        } else {
          ctx.save();
          ctx.clip();
          if (centerImageRef.current && centerImageRef.current.complete) {
            const s = centerRadius;
            ctx.drawImage(centerImageRef.current, -s, -s, s * 2, s * 2);
          } else {
            const grad = ctx.createLinearGradient(-centerRadius, -centerRadius, centerRadius, centerRadius);
            const colors = getColors();
            grad.addColorStop(0, colors[0]);
            grad.addColorStop(1, colors[colors.length - 1]);
            ctx.fillStyle = grad;
            ctx.fill();
          }
          ctx.restore();
        }

        // Outer Border
        if (centerArt.borderWidth > 0) {
          ctx.lineWidth = centerArt.borderWidth;
          ctx.strokeStyle = centerArt.borderColor || getGlowColor();
          ctx.stroke();
        }

        ctx.restore();
      };

      // 6. Draw Audio Visualizer Waveforms according to Mode
      const colors = getColors();
      const glowColor = getGlowColor();
      const barCount = waveform.barCount || 64;
      const sensitivity = waveform.sensitivity || 1.0;
      const heightScale = waveform.heightScale || 1.0;

      ctx.save();
      if (waveform.glowIntensity > 0) {
        ctx.shadowBlur = waveform.glowIntensity;
        ctx.shadowColor = glowColor;
      }

      // Helper to generate gradient along path
      const createWaveGradient = (x1: number, y1: number, x2: number, y2: number) => {
        const grad = ctx.createLinearGradient(x1, y1, x2, y2);
        colors.forEach((c, idx) => {
          grad.addColorStop(idx / (colors.length - 1), c);
        });
        return grad;
      };

      switch (waveform.mode) {
        case 'circular-bars':
        case 'vinyl-disk': {
          renderCenterArt();

          const innerR =
            centerArt.shape !== 'none'
              ? centerRadius + (centerArt.borderWidth || 2) + 12
              : minDim * (waveform.radius || 0.22);
          const maxBarH = minDim * 0.22 * heightScale;
          const angleStep = (Math.PI * 2) / barCount;

          for (let i = 0; i < barCount; i++) {
            // Mirrored frequency indexing around circle
            const binIdx =
              i < barCount / 2
                ? Math.floor((i / (barCount / 2)) * Math.min(128, smoothFreq.length * 0.4))
                : Math.floor(((barCount - i) / (barCount / 2)) * Math.min(128, smoothFreq.length * 0.4));

            const val = ((smoothFreq[binIdx] || 0) / 255) * sensitivity;
            const barH = Math.max(6, val * maxBarH);

            const angle = i * angleStep - Math.PI / 2;
            const cos = Math.cos(angle);
            const sin = Math.sin(angle);

            const x1 = centerX + cos * innerR;
            const y1 = centerY + sin * innerR;
            const x2 = centerX + cos * (innerR + barH);
            const y2 = centerY + sin * (innerR + barH);

            const colorIdx = Math.floor((i / barCount) * colors.length) % colors.length;
            ctx.strokeStyle = colors[colorIdx];
            ctx.lineWidth = waveform.barWidth || 5;
            ctx.lineCap = waveform.barRadius > 0 ? 'round' : 'butt';

            ctx.beginPath();
            ctx.moveTo(x1, y1);
            ctx.lineTo(x2, y2);
            ctx.stroke();

            // Circular peak cap dot
            if (peakBars[binIdx]) {
              const peakVal = (peakBars[binIdx] / 255) * sensitivity;
              const peakH = Math.max(8, peakVal * maxBarH);
              const px = centerX + cos * (innerR + peakH + 6);
              const py = centerY + sin * (innerR + peakH + 6);
              ctx.fillStyle = '#ffffff';
              ctx.beginPath();
              ctx.arc(px, py, (waveform.barWidth || 4) * 0.5, 0, Math.PI * 2);
              ctx.fill();
            }
          }
          break;
        }

        case 'neon-wave': {
          const waveY = height * (waveform.positionY || 0.5);
          const maxWaveH = height * 0.3 * heightScale;
          const pointsCount = Math.min(smoothFreq.length, barCount);
          const stepX = width / (pointsCount - 1);

          ctx.lineWidth = waveform.lineThickness || 4;
          ctx.strokeStyle = createWaveGradient(0, waveY - maxWaveH, width, waveY + maxWaveH);
          ctx.lineJoin = 'round';
          ctx.lineCap = 'round';

          // Multi-layer sine harmonics
          for (let layer = 0; layer < 3; layer++) {
            ctx.beginPath();
            const layerAlpha = layer === 0 ? 1 : 0.45 / layer;
            ctx.globalAlpha = layerAlpha;
            ctx.lineWidth = (waveform.lineThickness || 4) * (layer === 0 ? 1 : 0.6);

            for (let i = 0; i < pointsCount; i++) {
              const binIdx = Math.floor((i / pointsCount) * (smoothFreq.length * 0.5));
              const val = ((smoothFreq[binIdx] || 0) / 255) * sensitivity;
              const timeOffset = performance.now() * 0.003 * (layer + 1);
              const sineWave = Math.sin((i / pointsCount) * Math.PI * 6 + timeOffset) * 15;
              const yOffset = val * maxWaveH * (layer % 2 === 0 ? 1 : -0.7) + sineWave;
              const px = i * stepX;
              const py = waveY - yOffset;

              if (i === 0) {
                ctx.moveTo(px, py);
              } else {
                const prevX = (i - 1) * stepX;
                const cpx = (prevX + px) / 2;
                ctx.quadraticCurveTo(prevX, py, cpx, py);
              }
            }
            ctx.stroke();

            // Fill wave under bottom
            if (waveform.fillWave && layer === 0) {
              ctx.lineTo(width, height);
              ctx.lineTo(0, height);
              ctx.closePath();
              const fillGrad = ctx.createLinearGradient(0, waveY - maxWaveH, 0, height);
              fillGrad.addColorStop(0, `${colors[0]}44`);
              fillGrad.addColorStop(0.5, `${colors[1] || colors[0]}15`);
              fillGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
              ctx.fillStyle = fillGrad;
              ctx.fill();
            }
          }
          break;
        }

        case 'spectrum-bars': {
          const baseY = height * (waveform.positionY || 0.7);
          const maxBarH = height * 0.45 * heightScale;
          const totalWidth = width * 0.88;
          const startX = (width - totalWidth) / 2;
          const barW = Math.max(2, totalWidth / barCount - (waveform.barGap || 4));
          const step = totalWidth / barCount;

          const grad = ctx.createLinearGradient(0, baseY, 0, baseY - maxBarH);
          colors.forEach((c, idx) => grad.addColorStop(idx / (colors.length - 1), c));

          for (let i = 0; i < barCount; i++) {
            const binIdx = Math.floor((i / barCount) * (smoothFreq.length * 0.5));
            const val = ((smoothFreq[binIdx] || 0) / 255) * sensitivity;
            const barH = Math.max(4, val * maxBarH);
            const bx = startX + i * step;
            const by = baseY - barH;

            ctx.fillStyle = grad;
            ctx.beginPath();
            ctx.roundRect(bx, by, barW, barH, [waveform.barRadius || 4, waveform.barRadius || 4, 0, 0]);
            ctx.fill();

            // Floating peak cap
            if (peakBars[binIdx]) {
              const peakH = Math.max(4, ((peakBars[binIdx] || 0) / 255) * sensitivity * maxBarH);
              ctx.fillStyle = '#ffffff';
              ctx.beginPath();
              ctx.roundRect(bx, baseY - peakH - 6, barW, 3, 2);
              ctx.fill();
            }
          }
          break;
        }

        case 'dual-mirror': {
          renderCenterArt();

          const midY = height * (waveform.positionY || 0.5);
          const maxBarH = height * 0.28 * heightScale;
          const totalWidth = width * 0.9;
          const startX = (width - totalWidth) / 2;
          const halfBars = Math.floor(barCount / 2);
          const barW = Math.max(2, totalWidth / barCount - (waveform.barGap || 3));
          const step = totalWidth / barCount;

          for (let i = 0; i < barCount; i++) {
            // Symmetrical frequency distribution from center outward
            const distFromCenter = Math.abs(i - halfBars);
            const binIdx = Math.floor((distFromCenter / halfBars) * (smoothFreq.length * 0.45));
            const val = ((smoothFreq[binIdx] || 0) / 255) * sensitivity;
            const barH = Math.max(4, val * maxBarH);
            const bx = startX + i * step;

            const colorIdx = Math.floor((distFromCenter / halfBars) * colors.length) % colors.length;
            ctx.fillStyle = colors[colorIdx];

            // Top bar
            ctx.beginPath();
            ctx.roundRect(bx, midY - barH, barW, barH, [waveform.barRadius || 4, waveform.barRadius || 4, 0, 0]);
            ctx.fill();

            // Bottom mirrored bar
            ctx.beginPath();
            ctx.roundRect(bx, midY, barW, barH, [0, 0, waveform.barRadius || 4, waveform.barRadius || 4]);
            ctx.fill();
          }
          break;
        }

        case 'matrix-blocks': {
          const baseY = height * (waveform.positionY || 0.65);
          const maxBlocks = 24;
          const blockH = 8;
          const blockGap = 3;
          const totalWidth = width * 0.88;
          const startX = (width - totalWidth) / 2;
          const barW = Math.max(4, totalWidth / barCount - (waveform.barGap || 5));
          const step = totalWidth / barCount;

          for (let i = 0; i < barCount; i++) {
            const binIdx = Math.floor((i / barCount) * (smoothFreq.length * 0.5));
            const val = ((smoothFreq[binIdx] || 0) / 255) * sensitivity;
            const activeBlocks = Math.floor(val * maxBlocks * heightScale);
            const bx = startX + i * step;

            for (let b = 0; b < maxBlocks; b++) {
              const by = baseY - b * (blockH + blockGap);
              if (b < activeBlocks) {
                const ratio = b / maxBlocks;
                ctx.fillStyle =
                  ratio > 0.8 ? '#ef4444' : ratio > 0.6 ? '#f59e0b' : colors[0] || '#10b981';
                ctx.shadowBlur = waveform.glowIntensity > 0 ? 8 : 0;
                ctx.shadowColor = ctx.fillStyle;
              } else {
                ctx.fillStyle = 'rgba(255, 255, 255, 0.05)';
                ctx.shadowBlur = 0;
              }
              ctx.beginPath();
              ctx.roundRect(bx, by, barW, blockH, waveform.barRadius || 2);
              ctx.fill();
            }
          }
          break;
        }

        case 'particle-vortex':
        case 'cyber-ring': {
          renderCenterArt();

          const vortexR = minDim * (waveform.radius || 0.25);
          const ringsCount = 4;

          for (let r = 0; r < ringsCount; r++) {
            const ringRadius = vortexR + r * 28;
            const ringSpeed = (0.01 + r * 0.005) * (r % 2 === 0 ? 1 : -1);
            const ringAngle = rotationAngleRef.current * (r + 1) * ringSpeed;

            ctx.save();
            ctx.translate(centerX, centerY);
            ctx.rotate(ringAngle);

            const ringPoints = barCount / 2;
            const stepAng = (Math.PI * 2) / ringPoints;

            ctx.strokeStyle = colors[r % colors.length];
            ctx.lineWidth = 3;

            for (let p = 0; p < ringPoints; p++) {
              const binIdx = Math.floor((p / ringPoints) * (smoothFreq.length * 0.3));
              const val = ((smoothFreq[binIdx] || 0) / 255) * sensitivity;
              const spike = val * 50 * heightScale;
              const a = p * stepAng;

              const x1 = Math.cos(a) * ringRadius;
              const y1 = Math.sin(a) * ringRadius;
              const x2 = Math.cos(a) * (ringRadius + spike);
              const y2 = Math.sin(a) * (ringRadius + spike);

              ctx.beginPath();
              ctx.moveTo(x1, y1);
              ctx.lineTo(x2, y2);
              ctx.stroke();
            }
            ctx.restore();
          }
          break;
        }

        case 'smooth-blob': {
          renderCenterArt();
          const baseBlobR = minDim * (waveform.radius || 0.2);
          const numBlobPoints = 32;
          const angleStep = (Math.PI * 2) / numBlobPoints;

          ctx.save();
          ctx.translate(centerX, centerY);

          const grad = ctx.createRadialGradient(0, 0, 10, 0, 0, baseBlobR * 2);
          grad.addColorStop(0, `${colors[0]}88`);
          grad.addColorStop(0.7, `${colors[1] || colors[0]}55`);
          grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
          ctx.fillStyle = grad;
          ctx.strokeStyle = colors[0];
          ctx.lineWidth = 4;

          ctx.beginPath();
          for (let i = 0; i <= numBlobPoints; i++) {
            const idx = i % numBlobPoints;
            const binIdx = Math.floor((idx / numBlobPoints) * (smoothFreq.length * 0.3));
            const val = ((smoothFreq[binIdx] || 0) / 255) * sensitivity;
            const r = baseBlobR + val * minDim * 0.15 * heightScale;
            const a = idx * angleStep + performance.now() * 0.001;
            const px = Math.cos(a) * r;
            const py = Math.sin(a) * r;

            if (i === 0) {
              ctx.moveTo(px, py);
            } else {
              ctx.lineTo(px, py);
            }
          }
          ctx.closePath();
          ctx.fill();
          ctx.stroke();
          ctx.restore();
          break;
        }

        case 'linear-oscilloscope': {
          const oscY = height * (waveform.positionY || 0.5);
          const timeData = timeDataRef.current;
          const sliceW = width / timeData.length;

          ctx.lineWidth = waveform.lineThickness || 3;
          ctx.strokeStyle = colors[0] || '#22d3ee';
          ctx.beginPath();

          for (let i = 0; i < timeData.length; i++) {
            const v = timeData[i] / 128.0;
            const py = oscY + (v - 1) * height * 0.25 * heightScale * sensitivity;
            const px = i * sliceW;

            if (i === 0) {
              ctx.moveTo(px, py);
            } else {
              ctx.lineTo(px, py);
            }
          }
          ctx.stroke();
          break;
        }

        case 'polygon-morph': {
          renderCenterArt();

          const sides = Math.max(3, Math.min(16, Math.round(barCount / 8)));
          const baseR = minDim * (waveform.radius || 0.22);
          const maxSpike = minDim * 0.16 * heightScale;
          const angleStep = (Math.PI * 2) / sides;
          const rotation = rotationAngleRef.current * 1.5;

          ctx.save();
          ctx.translate(centerX, centerY);
          ctx.rotate(rotation);

          const grad = ctx.createRadialGradient(0, 0, baseR * 0.2, 0, 0, baseR + maxSpike);
          colors.forEach((c, idx) => grad.addColorStop(idx / Math.max(1, colors.length - 1), c));

          ctx.beginPath();
          for (let i = 0; i <= sides; i++) {
            const idx = i % sides;
            const binIdx = Math.floor((idx / sides) * (smoothFreq.length * 0.4));
            const val = ((smoothFreq[binIdx] || 0) / 255) * sensitivity;
            const r = baseR + val * maxSpike;
            const a = idx * angleStep;
            const px = Math.cos(a) * r;
            const py = Math.sin(a) * r;
            if (i === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
          }
          ctx.closePath();
          ctx.fillStyle = grad;
          ctx.globalAlpha = 0.35;
          ctx.fill();
          ctx.globalAlpha = 1;
          ctx.strokeStyle = colors[0];
          ctx.lineWidth = waveform.lineThickness || 3;
          ctx.stroke();

          // Vertex dots
          for (let i = 0; i < sides; i++) {
            const binIdx = Math.floor((i / sides) * (smoothFreq.length * 0.4));
            const val = ((smoothFreq[binIdx] || 0) / 255) * sensitivity;
            const r = baseR + val * maxSpike;
            const a = i * angleStep;
            ctx.fillStyle = colors[i % colors.length];
            ctx.beginPath();
            ctx.arc(Math.cos(a) * r, Math.sin(a) * r, (waveform.barWidth || 5) * 0.5, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.restore();
          break;
        }

        case 'starburst-rays': {
          renderCenterArt();

          const innerR =
            centerArt.shape !== 'none' ? centerRadius + (centerArt.borderWidth || 2) + 8 : minDim * 0.08;
          const maxRayLen = minDim * 0.32 * heightScale;
          const rayCount = Math.max(12, barCount);
          const angleStep = (Math.PI * 2) / rayCount;
          const rotation = rotationAngleRef.current * 0.6;

          for (let i = 0; i < rayCount; i++) {
            const binIdx = Math.floor((i / rayCount) * (smoothFreq.length * 0.4));
            const val = ((smoothFreq[binIdx] || 0) / 255) * sensitivity;
            const rayLen = Math.max(4, val * maxRayLen);
            const a = i * angleStep + rotation;
            const cos = Math.cos(a);
            const sin = Math.sin(a);

            const x1 = centerX + cos * innerR;
            const y1 = centerY + sin * innerR;
            const x2 = centerX + cos * (innerR + rayLen);
            const y2 = centerY + sin * (innerR + rayLen);

            const rayGrad = ctx.createLinearGradient(x1, y1, x2, y2);
            const colorIdx = Math.floor((i / rayCount) * colors.length) % colors.length;
            rayGrad.addColorStop(0, colors[colorIdx]);
            rayGrad.addColorStop(1, 'rgba(255,255,255,0)');

            ctx.strokeStyle = rayGrad;
            ctx.lineWidth = Math.max(1, (waveform.barWidth || 5) * 0.6);
            ctx.lineCap = 'round';
            ctx.beginPath();
            ctx.moveTo(x1, y1);
            ctx.lineTo(x2, y2);
            ctx.stroke();
          }
          break;
        }

        case 'ekg-pulse': {
          const lineY = height * (waveform.positionY || 0.5);
          const timeData = timeDataRef.current;
          const sliceW = width / timeData.length;

          // Faint scrolling grid baseline
          ctx.save();
          ctx.globalAlpha = 0.15;
          ctx.strokeStyle = colors[0];
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(0, lineY);
          ctx.lineTo(width, lineY);
          ctx.stroke();
          ctx.restore();

          ctx.lineWidth = waveform.lineThickness || 3;
          ctx.strokeStyle = colors[0] || '#22d3ee';
          ctx.lineJoin = 'round';
          ctx.beginPath();

          for (let i = 0; i < timeData.length; i++) {
            const v = (timeData[i] - 128) / 128.0;
            // Sharpen the signal so it reads like an EKG spike rather than a soft wave
            const sharpened = Math.sign(v) * Math.pow(Math.abs(v), 0.55);
            const py = lineY - sharpened * height * 0.32 * heightScale * sensitivity;
            const px = i * sliceW;

            if (i === 0) ctx.moveTo(px, py);
            else ctx.lineTo(px, py);
          }
          ctx.stroke();

          // Bass-triggered pulse dot travelling along the line
          if (avgBass > 0.3) {
            const dotX = ((performance.now() * 0.15) % width);
            ctx.fillStyle = colors[1] || colors[0];
            ctx.beginPath();
            ctx.arc(dotX, lineY, 5 + avgBass * 6, 0, Math.PI * 2);
            ctx.fill();
          }
          break;
        }

        case 'galaxy-spiral': {
          renderCenterArt();

          const armCount = 3;
          const pointsPerArm = Math.max(16, Math.floor(barCount / armCount));
          const maxRadius = minDim * 0.42 * heightScale;
          const rotation = rotationAngleRef.current * 2;

          for (let arm = 0; arm < armCount; arm++) {
            const armOffset = (Math.PI * 2 * arm) / armCount;

            for (let p = 0; p < pointsPerArm; p++) {
              const t = p / pointsPerArm;
              const binIdx = Math.floor(t * (smoothFreq.length * 0.4));
              const val = ((smoothFreq[binIdx] || 0) / 255) * sensitivity;

              const spiralAngle = t * Math.PI * 4 + armOffset + rotation;
              const radius = t * maxRadius * (0.6 + val * 0.4);

              const px = centerX + Math.cos(spiralAngle) * radius;
              const py = centerY + Math.sin(spiralAngle) * radius;
              const dotSize = Math.max(1, (1 - t) * 5 * (0.5 + val));

              ctx.fillStyle = colors[(arm + Math.floor(t * colors.length)) % colors.length];
              ctx.globalAlpha = 0.4 + val * 0.6;
              ctx.beginPath();
              ctx.arc(px, py, dotSize, 0, Math.PI * 2);
              ctx.fill();
            }
          }
          ctx.globalAlpha = 1;
          break;
        }
      }
      ctx.restore();

      // 7. Render Text Overlay & Metadata
      if (textOverlay.enabled) {
        ctx.save();
        const textY = (height * textOverlay.positionY) / 100;
        let alignX = centerX;
        if (textOverlay.alignment === 'left') alignX = width * 0.08;
        if (textOverlay.alignment === 'right') alignX = width * 0.92;

        ctx.textAlign = textOverlay.alignment;
        ctx.textBaseline = 'middle';

        if (textOverlay.dropShadow) {
          ctx.shadowColor = 'rgba(0, 0, 0, 0.85)';
          ctx.shadowBlur = 14;
          ctx.shadowOffsetX = 0;
          ctx.shadowOffsetY = 4;
        }

        // Title
        if (textOverlay.title) {
          ctx.font = `800 ${textOverlay.titleSize}px '${textOverlay.fontFamily}', sans-serif`;
          ctx.fillStyle = textOverlay.textColor || '#ffffff';
          ctx.fillText(textOverlay.title.toUpperCase(), alignX, textY);
        }

        // Artist / Subtext
        if (textOverlay.artist) {
          ctx.font = `600 ${textOverlay.artistSize}px '${textOverlay.fontFamily}', sans-serif`;
          ctx.fillStyle = textOverlay.accentColor || getGlowColor();
          ctx.fillText(textOverlay.artist.toUpperCase(), alignX, textY + textOverlay.titleSize * 0.8 + 6);
        }

        // Subtitle / Watermark
        if (textOverlay.subtext) {
          ctx.font = `500 ${Math.max(12, textOverlay.artistSize * 0.75)}px '${textOverlay.fontFamily}', sans-serif`;
          ctx.fillStyle = 'rgba(255, 255, 255, 0.6)';
          ctx.fillText(textOverlay.subtext, alignX, textY + textOverlay.titleSize * 0.8 + textOverlay.artistSize + 12);
        }

        // Timecode
        if (textOverlay.showTimestamp) {
          const timeStr = `${formatTime(currentTime)} / ${formatTime(duration)}`;
          ctx.font = `700 16px 'JetBrains Mono', monospace`;
          ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
          ctx.fillText(timeStr, alignX, textY - textOverlay.titleSize * 0.75 - 10);
        }

        // Watermark top-right
        if (textOverlay.showWatermark && textOverlay.watermarkText) {
          ctx.textAlign = 'right';
          ctx.font = `700 14px '${textOverlay.fontFamily}', sans-serif`;
          ctx.fillStyle = 'rgba(255, 255, 255, 0.4)';
          ctx.shadowBlur = 4;
          ctx.fillText(textOverlay.watermarkText.toUpperCase(), width - 36, 40);
        }

        ctx.restore();
      }

      // 8. Effects: Vignette & CRT Scanlines
      if (effects.vignette) {
        ctx.save();
        const vigGrad = ctx.createRadialGradient(
          centerX,
          centerY,
          minDim * 0.35,
          centerX,
          centerY,
          Math.max(width, height) * 0.7
        );
        vigGrad.addColorStop(0, 'rgba(0, 0, 0, 0)');
        vigGrad.addColorStop(1, `rgba(0, 0, 0, ${effects.vignetteStrength || 0.6})`);
        ctx.fillStyle = vigGrad;
        ctx.fillRect(0, 0, width, height);
        ctx.restore();
      }

      if (effects.scanlines) {
        ctx.save();
        ctx.fillStyle = 'rgba(0, 0, 0, 0.18)';
        for (let y = 0; y < height; y += 4) {
          ctx.fillRect(0, y, width, 1.5);
        }
        ctx.restore();
      }

      ctx.restore();
    }, [
      waveform,
      background,
      centerArt,
      textOverlay,
      effects,
      currentTime,
      duration,
      isPlaying,
      getColors,
      getGlowColor,
      aspectRatio,
    ]);

    // Request Animation Loop
    useEffect(() => {
      let isRunning = true;
      const loop = () => {
        if (!isRunning) return;
        renderFrame();
        animationFrameRef.current = requestAnimationFrame(loop);
      };
      animationFrameRef.current = requestAnimationFrame(loop);

      return () => {
        isRunning = false;
        if (animationFrameRef.current) {
          cancelAnimationFrame(animationFrameRef.current);
        }
      };
    }, [renderFrame]);

    // Expose capture and recording methods via ref
    useImperativeHandle(
      ref,
      () => ({
        captureSnapshot: (waveformOnly = false, resolutionScale = 1) => {
          const canvas = canvasRef.current;
          if (!canvas) return '';
          
          if (resolutionScale > 1) {
            const highResCanvas = document.createElement('canvas');
            highResCanvas.width = canvas.width * resolutionScale;
            highResCanvas.height = canvas.height * resolutionScale;
            const highResCtx = highResCanvas.getContext('2d');
            if (highResCtx) {
              highResCtx.imageSmoothingEnabled = true;
              highResCtx.imageSmoothingQuality = 'high';
              highResCtx.drawImage(canvas, 0, 0, highResCanvas.width, highResCanvas.height);
            }
            return highResCanvas.toDataURL('image/png');
          }

          if (waveformOnly) {
            // Render on temporary transparent canvas
            const tempCanvas = document.createElement('canvas');
            tempCanvas.width = canvas.width;
            tempCanvas.height = canvas.height;
            const tempCtx = tempCanvas.getContext('2d');
            if (tempCtx) {
              tempCtx.drawImage(canvas, 0, 0);
            }
            return tempCanvas.toDataURL('image/png');
          }
          return canvas.toDataURL('image/png');
        },
        startVideoRecording: async (onProgress, options) => {
          const canvas = canvasRef.current;
          if (!canvas) return;

          const targetFps = options?.fps || 60;
          const targetBitrate = options?.bitrate || 18000000; // 18 Mbps default

          try {
            // 1. Capture stream from canvas at configured FPS (60 or 30)
            const canvasStream = canvas.captureStream(targetFps);

            // 2. Mix pristine master audio stream from AudioEngine
            const audioDestination = audioEngine.getAudioOutputStream();
            const combinedStream = new MediaStream();

            canvasStream.getVideoTracks().forEach((track) => combinedStream.addTrack(track));
            if (audioDestination && audioDestination.stream.getAudioTracks().length > 0) {
              audioDestination.stream.getAudioTracks().forEach((track) => combinedStream.addTrack(track));
            }

            // 3. Supported MIME types with VP9/H264 fallback
            let mimeType = 'video/webm;codecs=vp9,opus';
            if (options?.format === 'mp4' && MediaRecorder.isTypeSupported('video/mp4;codecs=avc1,mp4a.40.2')) {
              mimeType = 'video/mp4;codecs=avc1,mp4a.40.2';
            } else if (options?.format === 'mp4' && MediaRecorder.isTypeSupported('video/mp4')) {
              mimeType = 'video/mp4';
            } else if (!MediaRecorder.isTypeSupported(mimeType)) {
              if (MediaRecorder.isTypeSupported('video/webm;codecs=vp8,opus')) {
                mimeType = 'video/webm;codecs=vp8,opus';
              } else if (MediaRecorder.isTypeSupported('video/webm;codecs=h264,opus')) {
                mimeType = 'video/webm;codecs=h264,opus';
              } else if (MediaRecorder.isTypeSupported('video/webm')) {
                mimeType = 'video/webm';
              } else if (MediaRecorder.isTypeSupported('video/mp4')) {
                mimeType = 'video/mp4';
              }
            }

            const recorder = new MediaRecorder(combinedStream, {
              mimeType,
              videoBitsPerSecond: targetBitrate,
            });

            recordedChunksRef.current = [];

            recorder.ondataavailable = (e) => {
              if (e.data && e.data.size > 0) {
                recordedChunksRef.current.push(e.data);
              }
            };

            recorder.start(100);
            mediaRecorderRef.current = recorder;
            setIsRecording(true);
            recordStartTimeRef.current = Date.now();

            if (recordingTimerRef.current) {
              clearInterval(recordingTimerRef.current);
            }

            recordingTimerRef.current = window.setInterval(() => {
              const elapsed = Math.floor((Date.now() - recordStartTimeRef.current) / 1000);
              onProgress?.(elapsed);
            }, 250);

            // Auto-play audio if paused
            if (!audioEngine.isPlaying) {
              audioEngine.play();
            }
          } catch (err) {
            console.error('Failed to start video recording:', err);
            setIsRecording(false);
          }
        },
        stopVideoRecording: async () => {
          const recorder = mediaRecorderRef.current;
          if (!recorder || recorder.state === 'inactive') {
            setIsRecording(false);
            return null;
          }

          if (recordingTimerRef.current) {
            clearInterval(recordingTimerRef.current);
            recordingTimerRef.current = null;
          }

          return new Promise<Blob | null>((resolve) => {
            recorder.onstop = () => {
              const blob = new Blob(recordedChunksRef.current, {
                type: recorder.mimeType || 'video/webm',
              });
              recordedChunksRef.current = [];
              setIsRecording(false);
              resolve(blob);
            };
            recorder.stop();
          });
        },
        isRecording,
      }),
      [isRecording]
    );

    // CSS aspect ratio mapping
    const getAspectClass = () => {
      switch (aspectRatio) {
        case '16:9':
          return 'aspect-video';
        case '9:16':
          return 'aspect-[9/16] max-h-[80vh]';
        case '1:1':
          return 'aspect-square max-h-[75vh]';
        case '4:3':
          return 'aspect-[4/3]';
        default:
          return 'aspect-video';
      }
    };

    const handleDragOver = (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDraggingOver(true);
      const items = e.dataTransfer.items;
      if (items && items.length > 0) {
        const item = items[0];
        if (item.type.startsWith('audio/')) {
          setDragKind('audio');
        } else if (item.type.startsWith('image/')) {
          setDragKind('image');
        } else {
          setDragKind('generic');
        }
      }
    };

    const handleDragLeave = (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDraggingOver(false);
    };

    const handleDrop = (e: React.DragEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setIsDraggingOver(false);
      const file = e.dataTransfer.files?.[0];
      if (!file) return;

      if (file.type.startsWith('audio/') || file.name.match(/\.(mp3|wav|flac|m4a|ogg|aac|opus)$/i)) {
        if (onDropAudio) onDropAudio(file);
      } else if (file.type.startsWith('image/') || file.name.match(/\.(jpg|jpeg|png|webp|gif|svg)$/i)) {
        if (onDropImage) onDropImage(file);
      }
    };

    return (
      <div
        ref={containerRef}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className={`relative w-full flex items-center justify-center overflow-hidden rounded-2xl bg-neutral-950/80 border shadow-2xl p-2 sm:p-4 backdrop-blur-xl group transition-all duration-300 ${
          isDraggingOver ? 'border-cyan-400 ring-4 ring-cyan-500/20 bg-neutral-900' : 'border-neutral-800'
        }`}
      >
        <div
          className={`relative w-full max-w-5xl overflow-hidden rounded-xl shadow-2xl border border-neutral-700/50 bg-black cursor-pointer transition-transform duration-300 ${getAspectClass()}`}
          onClick={onCanvasClick}
        >
          <canvas
            ref={canvasRef}
            className="w-full h-full object-contain block select-none pointer-events-none"
          />

          {/* Drag and Drop Active Overlay */}
          {isDraggingOver && (
            <div className="absolute inset-0 z-30 bg-neutral-950/85 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center animate-in fade-in duration-200">
              <div className="w-16 h-16 rounded-2xl bg-gradient-to-tr from-cyan-500 to-fuchsia-500 p-0.5 shadow-2xl mb-4 animate-bounce">
                <div className="w-full h-full bg-neutral-950 rounded-[14px] flex items-center justify-center text-white">
                  {dragKind === 'audio' ? (
                    <svg className="w-8 h-8 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 10l12-3" />
                    </svg>
                  ) : (
                    <svg className="w-8 h-8 text-fuchsia-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                  )}
                </div>
              </div>
              <h3 className="text-base sm:text-lg font-black text-white tracking-wide uppercase">
                {dragKind === 'audio'
                  ? 'ჩააგდეთ აუდიო ფაილი (MP3/WAV)'
                  : dragKind === 'image'
                  ? 'ჩააგდეთ სურათი ფონად (JPG/PNG)'
                  : 'ჩააგდეთ ფაილი (მუსიკა ან სურათი)'}
              </h3>
              <p className="text-xs text-neutral-400 mt-1 max-w-sm">
                ფაილი მყისიერად ჩაიტვირთება და ანიმაცია გააქტიურდება
              </p>
            </div>
          )}

          {/* Recording Badge Indicator */}
          {isRecording && (
            <div className="absolute top-4 left-4 z-20 flex items-center gap-2.5 px-3.5 py-1.5 rounded-full bg-red-950/90 border border-red-500/50 text-red-300 text-xs font-mono font-bold tracking-wider animate-pulse shadow-lg backdrop-blur-md">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" />
              REC • EXPORTING VIDEO
            </div>
          )}

          {/* Quick Direct Download Action Overlay Buttons (Top-Right) */}
          <div
            className="absolute top-3 right-3 z-20 flex items-center gap-1.5 opacity-90 hover:opacity-100 transition-opacity"
            onClick={(e) => e.stopPropagation()}
          >
            {onDirectDownloadPng && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDirectDownloadPng();
                }}
                className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-neutral-900/90 hover:bg-neutral-800 text-neutral-200 border border-neutral-700/80 text-[11px] font-bold shadow-lg backdrop-blur-md transition-all active:scale-95 hover:border-cyan-500/50"
                title={lang === 'ka' ? 'ფოტოს გადმოწერა (PNG)' : 'Download PNG'}
              >
                <svg className="w-3.5 h-3.5 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" />
                </svg>
                <span>{lang === 'ka' ? 'PNG' : 'PNG'}</span>
              </button>
            )}
            {onDirectRecordVideo && (
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onDirectRecordVideo();
                }}
                className={`flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-[11px] font-extrabold shadow-lg backdrop-blur-md transition-all active:scale-95 ${
                  isRecording
                    ? 'bg-red-500 text-white animate-pulse'
                    : 'bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-neutral-950 hover:brightness-110'
                }`}
                title={lang === 'ka' ? 'ვიდეოს ჩაწერა / გადმოწერა' : 'Record & Download Video'}
              >
                <svg className="w-3.5 h-3.5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 10l4.553-2.276A1 1 0 0121 8.618v6.764a1 1 0 01-1.447.894L15 14M5 18h8a2 2 0 002-2V8a2 2 0 00-2-2H5a2 2 0 00-2 2v8a2 2 0 002 2z" />
                </svg>
                <span>{isRecording ? (lang === 'ka' ? 'შეწყვეტა' : 'Stop') : lang === 'ka' ? 'ვიდეო' : 'Video'}</span>
              </button>
            )}
          </div>

          {/* Quick Play/Pause Hover Overlay */}
          {!isDraggingOver && (
            <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity duration-200 flex items-center justify-center pointer-events-none">
              <div className="p-4 rounded-full bg-neutral-900/80 border border-neutral-600/50 text-white backdrop-blur-md shadow-2xl transform scale-90 group-hover:scale-100 transition-transform">
                {isPlaying ? (
                  <svg className="w-8 h-8 fill-current" viewBox="0 0 24 24">
                    <path d="M6 4h4v16H6V4zm8 0h4v16h-4V4z" />
                  </svg>
                ) : (
                  <svg className="w-8 h-8 fill-current" viewBox="0 0 24 24">
                    <path d="M8 5v14l11-7z" />
                  </svg>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    );
  }
);
