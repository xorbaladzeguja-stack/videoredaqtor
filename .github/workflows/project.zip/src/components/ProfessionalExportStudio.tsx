import React, { useState } from 'react';
import {
  Film,
  Download,
  CheckCircle2,
  Sparkles,
  Layers,
  Settings2,
  ShieldCheck,
  Zap,
  Play,
  Square,
  Clock,
  Gauge,
  Sliders,
  Maximize,
} from 'lucide-react';
import { AspectRatioType } from '../types';

export interface VideoExportOptions {
  quality: '4k' | '1080p' | '720p';
  fps: 60 | 30;
  bitrate: number; // in bps
  format: 'webm' | 'mp4';
}

interface ProfessionalExportStudioProps {
  onStartRecording: (options: VideoExportOptions) => void;
  onStopRecording: () => void;
  isRecording: boolean;
  recordingProgress: number;
  onCaptureSnapshot: (waveformOnly?: boolean, resolutionScale?: number) => void;
  aspectRatio: AspectRatioType;
  duration: number;
  lang: 'en' | 'ka';
}

export const ProfessionalExportStudio: React.FC<ProfessionalExportStudioProps> = ({
  onStartRecording,
  onStopRecording,
  isRecording,
  recordingProgress,
  onCaptureSnapshot,
  aspectRatio,
  duration,
  lang,
}) => {
  const [quality, setQuality] = useState<'4k' | '1080p' | '720p'>('1080p');
  const [fps, setFps] = useState<60 | 30>(60);
  const [bitrate, setBitrate] = useState<number>(18000000); // 18 Mbps default for pristine quality
  const [format, setFormat] = useState<'webm' | 'mp4'>('webm');
  const [showAdvanced, setShowAdvanced] = useState<boolean>(false);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);

  const triggerSuccess = (label: string) => {
    setDownloadSuccess(label);
    setTimeout(() => setDownloadSuccess(null), 3000);
  };

  const handleStart = () => {
    onStartRecording({
      quality,
      fps,
      bitrate,
      format,
    });
  };

  const formatSecs = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = Math.floor(s % 60);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const t = {
    title: lang === 'ka' ? 'პროფესიონალური ვიდეო ექსპორტი (Studio Renderer)' : 'Professional Video Studio Export',
    subtitle:
      lang === 'ka'
        ? 'ვიდეო ედიტორების მსგავსი სრული რენდერი — 60 FPS, 4K/Full HD ხარისხი, სუფთა ხმა, 100% ვოთერმარკის გარეშე'
        : 'True Video Editor Master Rendering — 60 FPS, 4K/Full HD, Bitrate Control, 100% Watermark-Free',
    qualityLabel: lang === 'ka' ? 'გარჩევადობა (Resolution)' : 'Resolution Quality',
    fpsLabel: lang === 'ka' ? 'კადრების სიხშირე (FPS)' : 'Frame Rate (FPS)',
    bitrateLabel: lang === 'ka' ? 'ვიდეო ბიტრეიტი (Bitrate)' : 'Encoding Bitrate',
    startRecord: lang === 'ka' ? 'ვიდეოს ექსპორტის დაწყება' : 'Start Studio Video Render',
    stopRecord: lang === 'ka' ? 'დასრულება და პირდაპირ შენახვა' : 'Finish & Export Master Video',
    recordingActive: lang === 'ka' ? 'მიმდინარეობს პირდაპირი სტუდიური რენდერი...' : 'Master Video Rendering in Progress...',
    snapFull: lang === 'ka' ? '4K ულტრა ფოტოს შენახვა (PNG)' : 'Export 4K Master PNG',
    snapAlpha: lang === 'ka' ? 'გამჭვირვალე ტალღა (Alpha PNG)' : 'Transparent Alpha Waveform (PNG)',
    noWatermarkBadge: lang === 'ka' ? '100% სუფთა • No Watermark' : '100% Clean • No Watermark',
    proEngineBadge: lang === 'ka' ? 'Studio Engine v2.4' : 'Studio Engine v2.4',
  };

  return (
    <div className="w-full rounded-2xl bg-neutral-900/95 border border-cyan-500/30 p-4 sm:p-6 shadow-2xl backdrop-blur-xl space-y-6">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-neutral-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 via-sky-500 to-fuchsia-500 p-0.5 shadow-lg shadow-cyan-500/20">
            <div className="w-full h-full bg-neutral-950 rounded-[14px] flex items-center justify-center text-cyan-400">
              <Film className="w-6 h-6" />
            </div>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="text-base sm:text-lg font-black text-white tracking-wide">
                {t.title}
              </h3>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                {t.proEngineBadge}
              </span>
            </div>
            <p className="text-xs text-neutral-400 mt-0.5">{t.subtitle}</p>
          </div>
        </div>

        <div className="flex items-center gap-2 self-start sm:self-auto">
          <span className="inline-flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-xl bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 shadow-inner">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            {t.noWatermarkBadge}
          </span>
        </div>
      </div>

      {/* Main Studio Video Controls */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* 1. Resolution Selection */}
        <div className="bg-neutral-950/70 p-3.5 rounded-xl border border-neutral-800 space-y-2">
          <label className="text-xs font-bold text-neutral-300 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Maximize className="w-3.5 h-3.5 text-cyan-400" />
              {t.qualityLabel}
            </span>
            <span className="text-[11px] font-mono text-cyan-400 font-bold">
              {quality === '4k' ? '3840×2160 (4K UHD)' : quality === '1080p' ? '1920×1080 (FHD)' : '1280×720 (HD)'}
            </span>
          </label>
          <div className="grid grid-cols-3 gap-1.5">
            {(['720p', '1080p', '4k'] as const).map((q) => (
              <button
                key={q}
                disabled={isRecording}
                onClick={() => setQuality(q)}
                className={`py-2 rounded-lg text-xs font-black uppercase transition-all ${
                  quality === q
                    ? 'bg-gradient-to-r from-cyan-500 to-sky-500 text-neutral-950 shadow-md shadow-cyan-500/30'
                    : 'bg-neutral-800/80 hover:bg-neutral-750 text-neutral-300 border border-neutral-700/60'
                }`}
              >
                {q}
              </button>
            ))}
          </div>
        </div>

        {/* 2. FPS Selection */}
        <div className="bg-neutral-950/70 p-3.5 rounded-xl border border-neutral-800 space-y-2">
          <label className="text-xs font-bold text-neutral-300 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Gauge className="w-3.5 h-3.5 text-fuchsia-400" />
              {t.fpsLabel}
            </span>
            <span className="text-[11px] font-mono text-fuchsia-400 font-bold">
              {fps} FPS Smooth
            </span>
          </label>
          <div className="grid grid-cols-2 gap-1.5">
            {([30, 60] as const).map((f) => (
              <button
                key={f}
                disabled={isRecording}
                onClick={() => setFps(f)}
                className={`py-2 rounded-lg text-xs font-black transition-all ${
                  fps === f
                    ? 'bg-gradient-to-r from-fuchsia-500 to-pink-500 text-white shadow-md shadow-fuchsia-500/30'
                    : 'bg-neutral-800/80 hover:bg-neutral-750 text-neutral-300 border border-neutral-700/60'
                }`}
              >
                {f} FPS
              </button>
            ))}
          </div>
        </div>

        {/* 3. Output Format */}
        <div className="bg-neutral-950/70 p-3.5 rounded-xl border border-neutral-800 space-y-2">
          <label className="text-xs font-bold text-neutral-300 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-amber-400" />
              {lang === 'ka' ? 'კოდეკი / ფორმატი' : 'Encoder Format'}
            </span>
            <span className="text-[11px] font-mono text-amber-400 font-bold">
              {format === 'webm' ? 'WebM (VP9/Opus Master)' : 'MP4 (H.264/AAC)'}
            </span>
          </label>
          <div className="grid grid-cols-2 gap-1.5">
            {(['webm', 'mp4'] as const).map((fmt) => (
              <button
                key={fmt}
                disabled={isRecording}
                onClick={() => setFormat(fmt)}
                className={`py-2 rounded-lg text-xs font-black uppercase transition-all ${
                  format === fmt
                    ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-neutral-950 shadow-md shadow-amber-500/30'
                    : 'bg-neutral-800/80 hover:bg-neutral-750 text-neutral-300 border border-neutral-700/60'
                }`}
              >
                {fmt}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Advanced Bitrate Settings Toggle */}
      <div>
        <button
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="text-xs text-neutral-400 hover:text-cyan-300 flex items-center gap-1.5 transition-colors font-semibold"
        >
          <Settings2 className="w-3.5 h-3.5" />
          <span>
            {showAdvanced
              ? lang === 'ka'
                ? 'დეტალური პარამეტრების დამალვა'
                : 'Hide Advanced Bitrate Options'
              : lang === 'ka'
              ? 'დამატებითი ბიტრეიტის პარამეტრები (Bitrate Control)'
              : 'Advanced Bitrate & Encoder Settings'}
          </span>
        </button>

        {showAdvanced && (
          <div className="mt-3 p-4 rounded-xl bg-neutral-950/90 border border-neutral-800 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-neutral-300">{t.bitrateLabel}</span>
              <span className="font-mono text-cyan-400 font-extrabold">
                {(bitrate / 1000000).toFixed(1)} Mbps
              </span>
            </div>
            <input
              type="range"
              min={6000000}
              max={30000000}
              step={2000000}
              value={bitrate}
              disabled={isRecording}
              onChange={(e) => setBitrate(Number(e.target.value))}
              className="w-full h-2 bg-neutral-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
            <div className="flex justify-between text-[10px] font-mono text-neutral-500">
              <span>6 Mbps (Standard)</span>
              <span>18 Mbps (Studio Master)</span>
              <span>30 Mbps (Lossless 4K)</span>
            </div>
          </div>
        )}
      </div>

      {/* Big Master Action Area */}
      <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-cyan-950/40 via-neutral-950 to-fuchsia-950/40 border border-cyan-500/40 flex flex-col md:flex-row items-center justify-between gap-4">
        {/* Status info */}
        <div className="flex items-center gap-3 w-full md:w-auto">
          {isRecording ? (
            <div className="w-12 h-12 rounded-2xl bg-red-500/20 border border-red-500/50 flex items-center justify-center text-red-400 animate-pulse">
              <Clock className="w-6 h-6 animate-spin" />
            </div>
          ) : (
            <div className="w-12 h-12 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
              <Zap className="w-6 h-6" />
            </div>
          )}
          <div>
            <h4 className="text-sm font-bold text-white flex items-center gap-2">
              {isRecording ? (
                <>
                  <span className="text-red-400">{t.recordingActive}</span>
                  <span className="font-mono text-xs px-2 py-0.5 rounded bg-red-500/20 text-red-300 font-black">
                    {formatSecs(recordingProgress)}
                  </span>
                </>
              ) : (
                <span>
                  {lang === 'ka' ? 'მზად არის მაღალი ხარისხის რენდერისთვის' : 'Ready for Master Quality Export'}
                </span>
              )}
            </h4>
            <p className="text-xs text-neutral-400 mt-0.5">
              {isRecording
                ? lang === 'ka'
                  ? 'კადრი იწერება უწყვეტად შიდა 60 FPS ნაკადიდან სუფთა ხმით. დააჭირეთ დასრულებას ნებისმიერ დროს.'
                  : 'Recording direct internal 60 FPS frame stream with pristine master audio.'
                : `${quality.toUpperCase()} • ${fps} FPS • ${(bitrate / 1000000).toFixed(0)} Mbps • ${aspectRatio} • ${lang === 'ka' ? 'ვოთერმარკის გარეშე' : 'No Watermark'}`}
            </p>
          </div>
        </div>

        {/* Big Video Render Button */}
        <div className="w-full md:w-auto flex items-center gap-3">
          {isRecording ? (
            <button
              onClick={onStopRecording}
              className="w-full md:w-auto flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-red-500 hover:bg-red-400 text-white text-sm font-black tracking-wide shadow-xl shadow-red-500/30 animate-pulse transition-all active:scale-95 cursor-pointer"
            >
              <Square className="w-5 h-5 fill-current" />
              <span>{t.stopRecord}</span>
            </button>
          ) : (
            <button
              onClick={handleStart}
              className="w-full md:w-auto flex items-center justify-center gap-2.5 px-6 py-3.5 rounded-xl bg-gradient-to-r from-cyan-500 via-sky-400 to-fuchsia-500 hover:brightness-110 text-neutral-950 text-sm font-black tracking-wide shadow-xl shadow-cyan-500/30 transition-all active:scale-95 cursor-pointer"
            >
              <Play className="w-5 h-5 fill-current" />
              <span>{t.startRecord}</span>
            </button>
          )}
        </div>
      </div>

      {/* Snapshot Master Download Row */}
      <div className="pt-2 border-t border-neutral-800/80 flex flex-col sm:flex-row items-center justify-between gap-3">
        <span className="text-xs text-neutral-400 font-medium">
          {lang === 'ka' ? 'სტატიკური კადრების ექსპორტი (Master Photos):' : 'Export Master High-Res Snapshots:'}
        </span>

        <div className="flex items-center gap-2.5 w-full sm:w-auto">
          <button
            onClick={() => {
              onCaptureSnapshot(false, 2);
              triggerSuccess('png');
            }}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 text-neutral-100 text-xs font-bold transition-all shadow-md active:scale-95 hover:border-cyan-500/50"
          >
            {downloadSuccess === 'png' ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-300">{lang === 'ka' ? 'შენახულია!' : 'Saved!'}</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4 text-cyan-400" />
                <span>{t.snapFull}</span>
              </>
            )}
          </button>

          <button
            onClick={() => {
              onCaptureSnapshot(true, 2);
              triggerSuccess('alpha');
            }}
            className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 text-neutral-100 text-xs font-bold transition-all shadow-md active:scale-95 hover:border-fuchsia-500/50"
            title={lang === 'ka' ? 'გამჭვირვალე ფონი ვიდეო მონტაჟისთვის' : 'Transparent PNG for Premiere/AfterEffects/CapCut'}
          >
            {downloadSuccess === 'alpha' ? (
              <>
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span className="text-emerald-300">{lang === 'ka' ? 'შენახულია!' : 'Saved!'}</span>
              </>
            ) : (
              <>
                <Layers className="w-4 h-4 text-fuchsia-400" />
                <span>{t.snapAlpha}</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
