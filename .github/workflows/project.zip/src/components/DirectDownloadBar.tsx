import React, { useState } from 'react';
import {
  Download,
  Camera,
  Film,
  Sparkles,
  Layers,
  Check,
  Zap,
} from 'lucide-react';

interface DirectDownloadBarProps {
  onDownloadSnapshot: () => void;
  onDownloadTransparentPng: () => void;
  onStartVideoRecording: () => void;
  onStopVideoRecording: () => void;
  isRecording: boolean;
  recordingProgress: number;
  lang: 'en' | 'ka';
}

export const DirectDownloadBar: React.FC<DirectDownloadBarProps> = ({
  onDownloadSnapshot,
  onDownloadTransparentPng,
  onStartVideoRecording,
  onStopVideoRecording,
  isRecording,
  recordingProgress,
  lang,
}) => {
  const [downloadedFormat, setDownloadedFormat] = useState<string | null>(null);

  const triggerFeedback = (format: string, callback: () => void) => {
    setDownloadedFormat(format);
    callback();
    setTimeout(() => {
      setDownloadedFormat(null);
    }, 2500);
  };

  const t = {
    quickExport: lang === 'ka' ? 'პირდაპირი გადმოწერა' : 'Direct Quick Download',
    noWatermark: lang === 'ka' ? 'ვოთერმარკის გარეშე (HD/4K)' : 'No Watermark (Clean 4K)',
    downloadPng: lang === 'ka' ? 'სრული ფოტოს გადმოწერა (PNG)' : 'Download Full Image (PNG)',
    downloadTransparent: lang === 'ka' ? 'გამჭვირვალე ტალღა (PNG)' : 'Transparent Waveform (PNG)',
    recordVideo: lang === 'ka' ? 'ვიდეოს ჩაწერა / გადმოწერა (60 FPS)' : 'Record & Export Video (60 FPS)',
    recording: lang === 'ka' ? 'იწერება... დააჭირეთ დასრულებას' : 'Recording... Click to finish & download',
    saved: lang === 'ka' ? 'გადმოწერილია!' : 'Downloaded!',
  };

  return (
    <div className="w-full bg-gradient-to-r from-neutral-900 via-neutral-900/90 to-neutral-900 border border-cyan-500/30 rounded-2xl p-3 sm:p-4 shadow-xl flex flex-col md:flex-row items-center justify-between gap-3">
      {/* Label and Badge */}
      <div className="flex items-center gap-2.5 w-full md:w-auto justify-between md:justify-start">
        <div className="flex items-center gap-2.5">
          <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-fuchsia-500 p-0.5 shadow-md shadow-cyan-500/20">
            <div className="w-full h-full bg-neutral-950 rounded-[10px] flex items-center justify-center text-cyan-400">
              <Download className="w-4 h-4" />
            </div>
          </div>
          <div>
            <h3 className="text-xs sm:text-sm font-black text-white flex items-center gap-2">
              <span>{t.quickExport}</span>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                1-CLICK
              </span>
            </h3>
            <p className="text-[11px] text-neutral-400">{t.noWatermark}</p>
          </div>
        </div>
      </div>

      {/* 3 Prominent Download Action Buttons */}
      <div className="flex items-center gap-2 sm:gap-3 flex-wrap w-full md:w-auto justify-stretch sm:justify-end">
        {/* 1. Download Full Art PNG */}
        <button
          onClick={() => triggerFeedback('png', onDownloadSnapshot)}
          className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 active:scale-95 border border-neutral-700 text-white text-xs font-bold transition-all shadow-md hover:border-cyan-500/50 hover:shadow-cyan-500/10"
        >
          {downloadedFormat === 'png' ? (
            <>
              <Check className="w-4 h-4 text-emerald-400" />
              <span className="text-emerald-300">{t.saved}</span>
            </>
          ) : (
            <>
              <Camera className="w-4 h-4 text-cyan-400" />
              <span>{lang === 'ka' ? 'ფოტოს გადმოწერა (PNG)' : 'Download PNG'}</span>
            </>
          )}
        </button>

        {/* 2. Download Transparent Waveform PNG */}
        <button
          onClick={() => triggerFeedback('trans', onDownloadTransparentPng)}
          className="flex-1 sm:flex-none flex items-center justify-center gap-2 px-3.5 py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 active:scale-95 border border-neutral-700 text-neutral-200 text-xs font-bold transition-all shadow-md hover:border-fuchsia-500/50 hover:shadow-fuchsia-500/10"
          title={lang === 'ka' ? 'გამჭვირვალე ფონი დიზაინისთვის' : 'Transparent PNG for Design'}
        >
          {downloadedFormat === 'trans' ? (
            <>
              <Check className="w-4 h-4 text-emerald-400" />
              <span className="text-emerald-300">{t.saved}</span>
            </>
          ) : (
            <>
              <Layers className="w-4 h-4 text-fuchsia-400" />
              <span>{lang === 'ka' ? 'გამჭვირვალე ტალღა' : 'Transparent PNG'}</span>
            </>
          )}
        </button>

        {/* 3. Direct Video Recording & Export */}
        <button
          onClick={isRecording ? onStopVideoRecording : onStartVideoRecording}
          className={`flex-1 sm:flex-none flex items-center justify-center gap-2 px-4 py-2.5 rounded-xl text-xs font-extrabold transition-all shadow-lg active:scale-95 ${
            isRecording
              ? 'bg-red-500 text-white animate-pulse shadow-red-500/40 ring-2 ring-red-400'
              : 'bg-gradient-to-r from-cyan-500 via-sky-400 to-fuchsia-500 text-neutral-950 hover:brightness-110 shadow-cyan-500/25'
          }`}
        >
          <Film className="w-4 h-4" />
          <span>
            {isRecording
              ? `${lang === 'ka' ? 'დასრულება და გადმოწერა' : 'Finish & Download'} (${recordingProgress}s)`
              : lang === 'ka'
              ? 'ვიდეოს გადმოწერა (WebM/MP4)'
              : 'Export Video (WebM)'}
          </span>
        </button>
      </div>
    </div>
  );
};
