import React, { useState, useRef } from 'react';
import {
  Activity,
  Palette,
  Image as ImageIcon,
  Disc,
  Type,
  Sparkles,
  Download,
  Sliders,
  Upload,
  RefreshCw,
  Eye,
  Camera,
  Film,
  FileCode,
  Check,
  Flame,
  Zap,
} from 'lucide-react';
import {
  WaveformConfig,
  BackgroundConfig,
  CenterArtConfig,
  TextOverlayConfig,
  EffectsConfig,
  VisualizerMode,
  ColorPresetId,
  CenterArtShape,
} from '../types';
import {
  COLOR_PRESETS,
  BACKGROUND_PRESETS,
  CENTER_ART_PRESETS,
} from '../utils/presets';
import confetti from 'canvas-confetti';

interface ControlsPanelProps {
  waveform: WaveformConfig;
  setWaveform: React.Dispatch<React.SetStateAction<WaveformConfig>>;
  background: BackgroundConfig;
  setBackground: React.Dispatch<React.SetStateAction<BackgroundConfig>>;
  centerArt: CenterArtConfig;
  setCenterArt: React.Dispatch<React.SetStateAction<CenterArtConfig>>;
  textOverlay: TextOverlayConfig;
  setTextOverlay: React.Dispatch<React.SetStateAction<TextOverlayConfig>>;
  effects: EffectsConfig;
  setEffects: React.Dispatch<React.SetStateAction<EffectsConfig>>;
  onCaptureSnapshot: (waveformOnly?: boolean) => void;
  onStartVideoRecording: () => void;
  onStopVideoRecording: () => void;
  isRecording: boolean;
  recordingProgress: number;
  lang: 'en' | 'ka';
}

type TabKey = 'waveform' | 'colors' | 'background' | 'center' | 'text' | 'effects' | 'export';

export const ControlsPanel: React.FC<ControlsPanelProps> = ({
  waveform,
  setWaveform,
  background,
  setBackground,
  centerArt,
  setCenterArt,
  textOverlay,
  setTextOverlay,
  effects,
  setEffects,
  onCaptureSnapshot,
  onStartVideoRecording,
  onStopVideoRecording,
  isRecording,
  recordingProgress,
  lang,
}) => {
  const [activeTab, setActiveTab] = useState<TabKey>('waveform');
  const bgFileInputRef = useRef<HTMLInputElement | null>(null);
  const centerArtInputRef = useRef<HTMLInputElement | null>(null);
  const jsonImportRef = useRef<HTMLInputElement | null>(null);
  const [copiedPreset, setCopiedPreset] = useState(false);

  const t = {
    tabs: {
      waveform: lang === 'ka' ? 'ტალღა და სტილი' : 'Waveform',
      colors: lang === 'ka' ? 'ფერები და ნათება' : 'Colors & Glow',
      background: lang === 'ka' ? 'ფოტო / ფონი' : 'Background',
      center: lang === 'ka' ? 'ცენტრის ლოგო' : 'Center Art',
      text: lang === 'ka' ? 'ტექსტი / წარწერა' : 'Text Overlay',
      effects: lang === 'ka' ? 'ეფექტები' : 'Effects',
      export: lang === 'ka' ? 'დასეივება / ექსპორტი' : 'Export & Save',
    },
  };

  const visualizerModes: { id: VisualizerMode; name: string; nameKa: string; icon: string }[] = [
    { id: 'circular-bars', name: 'Radial Ring', nameKa: 'წრიული რინგი', icon: '⭕' },
    { id: 'neon-wave', name: 'Neon Wave', nameKa: 'ნეონის ტალღა', icon: '〰️' },
    { id: 'spectrum-bars', name: 'Spectrum Bars', nameKa: 'სპექტრი ზოლები', icon: '📊' },
    { id: 'dual-mirror', name: 'Dual Mirror', nameKa: 'სარკისებური', icon: '🪞' },
    { id: 'vinyl-disk', name: 'Vinyl Disk', nameKa: 'ვინილის ფირფიტა', icon: '📀' },
    { id: 'particle-vortex', name: 'Particle Vortex', nameKa: 'ვორტექსი', icon: '🌀' },
    { id: 'matrix-blocks', name: 'Matrix VU', nameKa: 'მატრიცა VU', icon: '🟩' },
    { id: 'smooth-blob', name: 'Liquid Blob', nameKa: 'თხევადი ბლოფი', icon: '🫧' },
    { id: 'linear-oscilloscope', name: 'Oscilloscope', nameKa: 'ოსცილოგრაფი', icon: '⚡' },
    { id: 'cyber-ring', name: 'Cyber Ring', nameKa: 'კიბერ რგოლი', icon: '💫' },
    { id: 'polygon-morph', name: 'Polygon Morph', nameKa: 'პოლიგონი', icon: '🔷' },
    { id: 'starburst-rays', name: 'Starburst Rays', nameKa: 'ვარსკვლავის სხივები', icon: '✨' },
    { id: 'ekg-pulse', name: 'EKG Pulse', nameKa: 'პულსი (EKG)', icon: '💓' },
    { id: 'galaxy-spiral', name: 'Galaxy Spiral', nameKa: 'გალაქტიკის სპირალი', icon: '🌌' },
  ];

  const handleBgImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setBackground((prev) => ({
        ...prev,
        type: 'image',
        imageUrl: url,
      }));
    }
  };

  const handleCenterArtUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const url = URL.createObjectURL(file);
      setCenterArt((prev) => ({
        ...prev,
        shape: prev.shape === 'none' ? 'circle' : prev.shape,
        imageUrl: url,
      }));
    }
  };

  const handleExportJSON = () => {
    const config = {
      waveform,
      background,
      centerArt,
      textOverlay,
      effects,
      exportedAt: new Date().toISOString(),
    };
    const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `waveform-preset-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    confetti({ particleCount: 50, spread: 60 });
  };

  const handleImportJSON = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      try {
        const data = JSON.parse(ev.target?.result as string);
        if (data.waveform) setWaveform((prev) => ({ ...prev, ...data.waveform }));
        if (data.background) setBackground((prev) => ({ ...prev, ...data.background }));
        if (data.centerArt) setCenterArt((prev) => ({ ...prev, ...data.centerArt }));
        if (data.textOverlay) setTextOverlay((prev) => ({ ...prev, ...data.textOverlay }));
        if (data.effects) setEffects((prev) => ({ ...prev, ...data.effects }));
        confetti({ particleCount: 70, spread: 70 });
      } catch (err) {
        alert('Invalid preset JSON file');
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="w-full bg-neutral-900/90 border border-neutral-800 rounded-2xl shadow-2xl backdrop-blur-xl flex flex-col overflow-hidden">
      {/* Navigation Tabs Header */}
      <div className="flex items-center gap-1 overflow-x-auto p-2 bg-neutral-950/70 border-b border-neutral-800/80 scrollbar-none">
        <button
          onClick={() => setActiveTab('waveform')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
            activeTab === 'waveform'
              ? 'bg-cyan-500 text-neutral-950 shadow-md shadow-cyan-500/25'
              : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
          }`}
        >
          <Activity className="w-3.5 h-3.5" />
          <span>{t.tabs.waveform}</span>
        </button>

        <button
          onClick={() => setActiveTab('colors')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
            activeTab === 'colors'
              ? 'bg-cyan-500 text-neutral-950 shadow-md shadow-cyan-500/25'
              : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
          }`}
        >
          <Palette className="w-3.5 h-3.5" />
          <span>{t.tabs.colors}</span>
        </button>

        <button
          onClick={() => setActiveTab('background')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
            activeTab === 'background'
              ? 'bg-cyan-500 text-neutral-950 shadow-md shadow-cyan-500/25'
              : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
          }`}
        >
          <ImageIcon className="w-3.5 h-3.5" />
          <span>{t.tabs.background}</span>
        </button>

        <button
          onClick={() => setActiveTab('center')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
            activeTab === 'center'
              ? 'bg-cyan-500 text-neutral-950 shadow-md shadow-cyan-500/25'
              : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
          }`}
        >
          <Disc className="w-3.5 h-3.5" />
          <span>{t.tabs.center}</span>
        </button>

        <button
          onClick={() => setActiveTab('text')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
            activeTab === 'text'
              ? 'bg-cyan-500 text-neutral-950 shadow-md shadow-cyan-500/25'
              : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
          }`}
        >
          <Type className="w-3.5 h-3.5" />
          <span>{t.tabs.text}</span>
        </button>

        <button
          onClick={() => setActiveTab('effects')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
            activeTab === 'effects'
              ? 'bg-cyan-500 text-neutral-950 shadow-md shadow-cyan-500/25'
              : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>{t.tabs.effects}</span>
        </button>

        <button
          onClick={() => setActiveTab('export')}
          className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold whitespace-nowrap transition-all ${
            activeTab === 'export'
              ? 'bg-fuchsia-500 text-neutral-950 shadow-md shadow-fuchsia-500/25'
              : 'text-fuchsia-400 hover:text-fuchsia-300 hover:bg-fuchsia-500/10'
          }`}
        >
          <Download className="w-3.5 h-3.5" />
          <span>{t.tabs.export}</span>
        </button>
      </div>

      {/* Tab Contents */}
      <div className="p-4 sm:p-5 max-h-[500px] overflow-y-auto">
        {/* 1. Waveform & Style Tab */}
        {activeTab === 'waveform' && (
          <div className="space-y-5">
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-2.5">
                {lang === 'ka' ? 'ტალღის ვიზუალიზაციის რეჟიმი' : 'Waveform Visualizer Mode'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {visualizerModes.map((mode) => (
                  <button
                    key={mode.id}
                    onClick={() => setWaveform((prev) => ({ ...prev, mode: mode.id }))}
                    className={`flex items-center gap-2.5 p-2.5 rounded-xl border text-xs font-semibold text-left transition-all ${
                      waveform.mode === mode.id
                        ? 'bg-cyan-500/15 border-cyan-500 text-cyan-300 shadow-md shadow-cyan-500/10'
                        : 'bg-neutral-800/50 border-neutral-700/70 text-neutral-300 hover:bg-neutral-800 hover:text-white'
                    }`}
                  >
                    <span className="text-base">{mode.icon}</span>
                    <span className="truncate">{lang === 'ka' ? mode.nameKa : mode.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Sensitivity */}
              <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-800">
                <div className="flex justify-between text-xs font-semibold mb-1.5 text-neutral-300">
                  <span>{lang === 'ka' ? 'მგრძნობელობა (Sensitivity)' : 'Audio Sensitivity'}</span>
                  <span className="font-mono text-cyan-400">{waveform.sensitivity.toFixed(1)}x</span>
                </div>
                <input
                  type="range"
                  min={0.5}
                  max={3.0}
                  step={0.1}
                  value={waveform.sensitivity}
                  onChange={(e) =>
                    setWaveform((prev) => ({ ...prev, sensitivity: parseFloat(e.target.value) }))
                  }
                  className="w-full accent-cyan-400 h-1.5 bg-neutral-700 rounded-lg cursor-pointer"
                />
              </div>

              {/* Height Scale */}
              <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-800">
                <div className="flex justify-between text-xs font-semibold mb-1.5 text-neutral-300">
                  <span>{lang === 'ka' ? 'ტალღის სიმაღლე (Scale)' : 'Waveform Height'}</span>
                  <span className="font-mono text-cyan-400">{waveform.heightScale.toFixed(1)}x</span>
                </div>
                <input
                  type="range"
                  min={0.4}
                  max={2.5}
                  step={0.1}
                  value={waveform.heightScale}
                  onChange={(e) =>
                    setWaveform((prev) => ({ ...prev, heightScale: parseFloat(e.target.value) }))
                  }
                  className="w-full accent-cyan-400 h-1.5 bg-neutral-700 rounded-lg cursor-pointer"
                />
              </div>

              {/* Smoothing */}
              <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-800">
                <div className="flex justify-between text-xs font-semibold mb-1.5 text-neutral-300">
                  <span>{lang === 'ka' ? 'დარბილება (Smoothing)' : 'FFT Smoothing'}</span>
                  <span className="font-mono text-cyan-400">{Math.round(waveform.smoothing * 100)}%</span>
                </div>
                <input
                  type="range"
                  min={0.3}
                  max={0.95}
                  step={0.05}
                  value={waveform.smoothing}
                  onChange={(e) =>
                    setWaveform((prev) => ({ ...prev, smoothing: parseFloat(e.target.value) }))
                  }
                  className="w-full accent-cyan-400 h-1.5 bg-neutral-700 rounded-lg cursor-pointer"
                />
              </div>

              {/* Bar Count */}
              <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-800">
                <div className="flex justify-between text-xs font-semibold mb-1.5 text-neutral-300">
                  <span>{lang === 'ka' ? 'ზოლების რაოდენობა' : 'Bar Count / Resolution'}</span>
                  <span className="font-mono text-cyan-400">{waveform.barCount}</span>
                </div>
                <input
                  type="range"
                  min={32}
                  max={256}
                  step={16}
                  value={waveform.barCount}
                  onChange={(e) =>
                    setWaveform((prev) => ({ ...prev, barCount: parseInt(e.target.value) }))
                  }
                  className="w-full accent-cyan-400 h-1.5 bg-neutral-700 rounded-lg cursor-pointer"
                />
              </div>

              {/* Bar Width */}
              <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-800">
                <div className="flex justify-between text-xs font-semibold mb-1.5 text-neutral-300">
                  <span>{lang === 'ka' ? 'სისქე / სიგანე' : 'Bar / Line Width'}</span>
                  <span className="font-mono text-cyan-400">{waveform.barWidth}px</span>
                </div>
                <input
                  type="range"
                  min={1}
                  max={20}
                  step={1}
                  value={waveform.barWidth}
                  onChange={(e) =>
                    setWaveform((prev) => ({
                      ...prev,
                      barWidth: parseInt(e.target.value),
                      lineThickness: parseInt(e.target.value),
                    }))
                  }
                  className="w-full accent-cyan-400 h-1.5 bg-neutral-700 rounded-lg cursor-pointer"
                />
              </div>

              {/* Position Y */}
              <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-800">
                <div className="flex justify-between text-xs font-semibold mb-1.5 text-neutral-300">
                  <span>{lang === 'ka' ? 'ვერტიკალური პოზიცია' : 'Vertical Position (Y)'}</span>
                  <span className="font-mono text-cyan-400">{Math.round(waveform.positionY * 100)}%</span>
                </div>
                <input
                  type="range"
                  min={0.15}
                  max={0.85}
                  step={0.02}
                  value={waveform.positionY}
                  onChange={(e) =>
                    setWaveform((prev) => ({ ...prev, positionY: parseFloat(e.target.value) }))
                  }
                  className="w-full accent-cyan-400 h-1.5 bg-neutral-700 rounded-lg cursor-pointer"
                />
              </div>
            </div>
          </div>
        )}

        {/* 2. Colors & Glow Tab */}
        {activeTab === 'colors' && (
          <div className="space-y-5">
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-2.5">
                {lang === 'ka' ? 'ფერების პალიტრები' : 'Color Gradient Themes'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {Object.values(COLOR_PRESETS).map((preset) => (
                  <button
                    key={preset.id}
                    onClick={() => setWaveform((prev) => ({ ...prev, colorPreset: preset.id }))}
                    className={`flex flex-col gap-2 p-2.5 rounded-xl border text-xs font-semibold transition-all text-left ${
                      waveform.colorPreset === preset.id
                        ? 'bg-neutral-800 border-cyan-400 ring-1 ring-cyan-400/50 text-white'
                        : 'bg-neutral-800/40 border-neutral-700/60 text-neutral-300 hover:bg-neutral-800'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span>{preset.name}</span>
                      {waveform.colorPreset === preset.id && (
                        <Check className="w-3.5 h-3.5 text-cyan-400" />
                      )}
                    </div>
                    <div className="flex h-3 w-full rounded-md overflow-hidden shadow-inner">
                      {preset.colors.map((c, i) => (
                        <div key={i} className="flex-1 h-full" style={{ backgroundColor: c }} />
                      ))}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Glow Intensity */}
            <div className="bg-neutral-800/40 p-3.5 rounded-xl border border-neutral-800">
              <div className="flex justify-between text-xs font-semibold mb-1.5 text-neutral-300">
                <span className="flex items-center gap-1.5">
                  <Zap className="w-4 h-4 text-amber-400" />
                  {lang === 'ka' ? 'ნათების / Glow სიძლიერე' : 'Glow / Bloom Strength'}
                </span>
                <span className="font-mono text-amber-400">{waveform.glowIntensity}px</span>
              </div>
              <input
                type="range"
                min={0}
                max={40}
                step={2}
                value={waveform.glowIntensity}
                onChange={(e) =>
                  setWaveform((prev) => ({ ...prev, glowIntensity: parseInt(e.target.value) }))
                }
                className="w-full accent-amber-400 h-1.5 bg-neutral-700 rounded-lg cursor-pointer"
              />
            </div>

            {/* Custom Colors Picker if custom */}
            {waveform.colorPreset === 'custom' && (
              <div className="bg-neutral-800/40 p-3.5 rounded-xl border border-neutral-800 space-y-3">
                <p className="text-xs font-bold uppercase text-neutral-400">
                  {lang === 'ka' ? 'თქვენი გრადიენტის ფერები' : 'Custom Gradient Color Stops'}
                </p>
                <div className="flex items-center gap-3">
                  {waveform.customColors.map((color, idx) => (
                    <div key={idx} className="flex items-center gap-2">
                      <input
                        type="color"
                        value={color}
                        onChange={(e) => {
                          const updated = [...waveform.customColors];
                          updated[idx] = e.target.value;
                          setWaveform((prev) => ({ ...prev, customColors: updated }));
                        }}
                        className="w-8 h-8 rounded-lg cursor-pointer bg-transparent border border-neutral-700"
                      />
                      <span className="text-xs font-mono text-neutral-300">{color}</span>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}

        {/* 3. Background & Photo Tab (ფოტო / ფონი) */}
        {activeTab === 'background' && (
          <div className="space-y-5">
            {/* Custom Photo Upload */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3.5 rounded-xl bg-gradient-to-r from-neutral-800/60 to-cyan-950/30 border border-cyan-500/20">
              <div>
                <h4 className="text-xs font-bold uppercase text-cyan-300 mb-0.5">
                  {lang === 'ka' ? 'საკუთარი ფოტოს / სურათის ატვირთვა' : 'Upload Custom Background Photo'}
                </h4>
                <p className="text-xs text-neutral-400">
                  {lang === 'ka'
                    ? 'ატვირთეთ ნებისმიერი JPG, PNG ან WebP ფოტო'
                    : 'Upload any high-res JPG, PNG or WebP image'}
                </p>
              </div>

              <input
                ref={bgFileInputRef}
                type="file"
                accept="image/*"
                className="hidden"
                onChange={handleBgImageUpload}
              />
              <button
                onClick={() => bgFileInputRef.current?.click()}
                className="flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-neutral-950 text-xs font-bold transition-all shadow-md shadow-cyan-500/20"
              >
                <Upload className="w-3.5 h-3.5" />
                <span>{lang === 'ka' ? 'ფოტოს არჩევა' : 'Choose Photo'}</span>
              </button>
            </div>

            {/* Curated Preset Backgrounds */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-2.5">
                {lang === 'ka' ? 'მზა HD ფონები' : 'Curated HD Backgrounds'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                {BACKGROUND_PRESETS.map((bg) => (
                  <button
                    key={bg.id}
                    onClick={() =>
                      setBackground((prev) => ({
                        ...prev,
                        type: 'image',
                        imageUrl: bg.url,
                      }))
                    }
                    className={`group relative aspect-video rounded-xl overflow-hidden border transition-all ${
                      background.imageUrl === bg.url && background.type === 'image'
                        ? 'border-cyan-400 ring-2 ring-cyan-400/50 scale-[1.02]'
                        : 'border-neutral-700/60 opacity-70 hover:opacity-100 hover:border-neutral-500'
                    }`}
                  >
                    <img src={bg.thumb} alt={bg.name} className="w-full h-full object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex items-end p-2">
                      <span className="text-[11px] font-bold text-white truncate">
                        {lang === 'ka' ? bg.nameKa : bg.name}
                      </span>
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Background Sliders */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {/* Blur */}
              <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-800">
                <div className="flex justify-between text-xs font-semibold mb-1.5 text-neutral-300">
                  <span>{lang === 'ka' ? 'ფონის დაბინდვა (Blur)' : 'Background Blur'}</span>
                  <span className="font-mono text-cyan-400">{background.blur}px</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={30}
                  step={1}
                  value={background.blur}
                  onChange={(e) =>
                    setBackground((prev) => ({ ...prev, blur: parseInt(e.target.value) }))
                  }
                  className="w-full accent-cyan-400 h-1.5 bg-neutral-700 rounded-lg cursor-pointer"
                />
              </div>

              {/* Darkness / Dim */}
              <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-800">
                <div className="flex justify-between text-xs font-semibold mb-1.5 text-neutral-300">
                  <span>{lang === 'ka' ? 'ფონის ჩაბნელება (Dim)' : 'Darkness Overlay'}</span>
                  <span className="font-mono text-cyan-400">{Math.round(background.dim * 100)}%</span>
                </div>
                <input
                  type="range"
                  min={0}
                  max={0.9}
                  step={0.05}
                  value={background.dim}
                  onChange={(e) =>
                    setBackground((prev) => ({ ...prev, dim: parseFloat(e.target.value) }))
                  }
                  className="w-full accent-cyan-400 h-1.5 bg-neutral-700 rounded-lg cursor-pointer"
                />
              </div>

              {/* Reactive Bass Pulse */}
              <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-800 sm:col-span-2 flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-neutral-200 block">
                    {lang === 'ka' ? 'ბასზე ფონის პულსირება (Bass Pulse Zoom)' : 'Reactive Bass Zoom Pulse'}
                  </span>
                  <span className="text-[11px] text-neutral-400">
                    {lang === 'ka'
                      ? 'ფონი რიტმულად ირხევა ბასის დარტყმებზე'
                      : 'Background zooms dynamically on heavy bass transients'}
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={background.pulseWithBass}
                  onChange={(e) =>
                    setBackground((prev) => ({ ...prev, pulseWithBass: e.target.checked }))
                  }
                  className="w-5 h-5 accent-cyan-400 rounded cursor-pointer"
                />
              </div>
            </div>
          </div>
        )}

        {/* 4. Center Art / Logo Tab */}
        {activeTab === 'center' && (
          <div className="space-y-5">
            {/* Shape selection */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-2.5">
                {lang === 'ka' ? 'ცენტრის ლოგოს ფორმა' : 'Center Badge Shape'}
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-2">
                {[
                  { id: 'circle', name: 'Circle', nameKa: 'წრე' },
                  { id: 'vinyl', name: 'Vinyl', nameKa: 'ვინილი' },
                  { id: 'rounded', name: 'Rounded', nameKa: 'მომრგვალებული' },
                  { id: 'square', name: 'Square', nameKa: 'კვადრატი' },
                  { id: 'none', name: 'Disabled', nameKa: 'გამორთვა' },
                ].map((shape) => (
                  <button
                    key={shape.id}
                    onClick={() =>
                      setCenterArt((prev) => ({ ...prev, shape: shape.id as CenterArtShape }))
                    }
                    className={`py-2 px-3 rounded-xl border text-xs font-semibold text-center transition-all ${
                      centerArt.shape === shape.id
                        ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                        : 'bg-neutral-800/40 border-neutral-700/60 text-neutral-400 hover:text-white'
                    }`}
                  >
                    {lang === 'ka' ? shape.nameKa : shape.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Center Logo Upload */}
            {centerArt.shape !== 'none' && (
              <>
                <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-3.5 rounded-xl bg-neutral-800/50 border border-neutral-700">
                  <div>
                    <h4 className="text-xs font-bold uppercase text-neutral-200 mb-0.5">
                      {lang === 'ka' ? 'ცენტრის ლოგოს / ქავერის ატვირთვა' : 'Upload Center Artwork / Album Cover'}
                    </h4>
                    <p className="text-xs text-neutral-400">
                      {lang === 'ka' ? 'დააყენეთ თქვენი სიმღერის ქავერი' : 'PNG or JPG badge / artwork'}
                    </p>
                  </div>
                  <input
                    ref={centerArtInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleCenterArtUpload}
                  />
                  <button
                    onClick={() => centerArtInputRef.current?.click()}
                    className="flex items-center gap-2 px-3.5 py-1.5 rounded-xl bg-neutral-700 hover:bg-neutral-600 text-white text-xs font-semibold transition-all"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>{lang === 'ka' ? 'ატვირთვა' : 'Upload'}</span>
                  </button>
                </div>

                {/* Preset Avatars */}
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-neutral-400 block mb-2">
                    {lang === 'ka' ? 'მზა ლოგოები' : 'Preset Art Badges'}
                  </label>
                  <div className="flex gap-2.5">
                    {CENTER_ART_PRESETS.map((preset) => (
                      <button
                        key={preset.id}
                        onClick={() =>
                          setCenterArt((prev) => ({
                            ...prev,
                            imageUrl: preset.url,
                          }))
                        }
                        className={`w-12 h-12 rounded-xl overflow-hidden border transition-all ${
                          centerArt.imageUrl === preset.url
                            ? 'border-cyan-400 ring-2 ring-cyan-400/50 scale-105'
                            : 'border-neutral-700 opacity-60 hover:opacity-100'
                        }`}
                      >
                        <img src={preset.url} alt={preset.name} className="w-full h-full object-cover" />
                      </button>
                    ))}
                  </div>
                </div>

                {/* Sliders */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Size */}
                  <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-800">
                    <div className="flex justify-between text-xs font-semibold mb-1.5 text-neutral-300">
                      <span>{lang === 'ka' ? 'ზომა' : 'Badge Size'}</span>
                      <span className="font-mono text-cyan-400">{Math.round(centerArt.size * 100)}%</span>
                    </div>
                    <input
                      type="range"
                      min={0.15}
                      max={0.45}
                      step={0.02}
                      value={centerArt.size}
                      onChange={(e) =>
                        setCenterArt((prev) => ({ ...prev, size: parseFloat(e.target.value) }))
                      }
                      className="w-full accent-cyan-400 h-1.5 bg-neutral-700 rounded-lg cursor-pointer"
                    />
                  </div>

                  {/* Rotation Speed */}
                  <div className="bg-neutral-800/40 p-3 rounded-xl border border-neutral-800">
                    <div className="flex justify-between text-xs font-semibold mb-1.5 text-neutral-300">
                      <span>{lang === 'ka' ? 'ტრიალის სიჩქარე' : 'Rotation Speed'}</span>
                      <span className="font-mono text-cyan-400">{centerArt.rotationSpeed}x</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={3}
                      step={0.2}
                      value={centerArt.rotationSpeed}
                      onChange={(e) =>
                        setCenterArt((prev) => ({ ...prev, rotationSpeed: parseFloat(e.target.value) }))
                      }
                      className="w-full accent-cyan-400 h-1.5 bg-neutral-700 rounded-lg cursor-pointer"
                    />
                  </div>
                </div>
              </>
            )}
          </div>
        )}

        {/* 5. Text & Overlay Tab */}
        {activeTab === 'text' && (
          <div className="space-y-4">
            <div className="flex items-center justify-between p-3 rounded-xl bg-neutral-800/50 border border-neutral-700">
              <span className="text-xs font-bold text-neutral-200">
                {lang === 'ka' ? 'ტექსტის გამოჩენა (Enable Overlay)' : 'Enable Text Overlay'}
              </span>
              <input
                type="checkbox"
                checked={textOverlay.enabled}
                onChange={(e) => setTextOverlay((prev) => ({ ...prev, enabled: e.target.checked }))}
                className="w-5 h-5 accent-cyan-400 rounded cursor-pointer"
              />
            </div>

            {textOverlay.enabled && (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-neutral-400 block mb-1">
                      {lang === 'ka' ? 'სიმღერის სახელი (Title)' : 'Track Title'}
                    </label>
                    <input
                      type="text"
                      value={textOverlay.title}
                      onChange={(e) =>
                        setTextOverlay((prev) => ({ ...prev, title: e.target.value }))
                      }
                      placeholder="e.g. CYBER OVERDRIVE"
                      className="w-full px-3 py-2 rounded-xl bg-neutral-800 border border-neutral-700 text-xs text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>

                  <div>
                    <label className="text-xs font-bold text-neutral-400 block mb-1">
                      {lang === 'ka' ? 'ავტორი / არტისტი (Artist)' : 'Artist / Producer'}
                    </label>
                    <input
                      type="text"
                      value={textOverlay.artist}
                      onChange={(e) =>
                        setTextOverlay((prev) => ({ ...prev, artist: e.target.value }))
                      }
                      placeholder="e.g. DJ RESONANCE"
                      className="w-full px-3 py-2 rounded-xl bg-neutral-800 border border-neutral-700 text-xs text-white focus:outline-none focus:border-cyan-400"
                    />
                  </div>
                </div>

                {/* Subtext */}
                <div>
                  <label className="text-xs font-bold text-neutral-400 block mb-1">
                    {lang === 'ka' ? 'დამატებითი წარწერა / ქვეტექსტი' : 'Subtext / Description'}
                  </label>
                  <input
                    type="text"
                    value={textOverlay.subtext}
                    onChange={(e) =>
                      setTextOverlay((prev) => ({ ...prev, subtext: e.target.value }))
                    }
                    placeholder="e.g. 4K AUDIO VISUALIZER"
                    className="w-full px-3 py-2 rounded-xl bg-neutral-800 border border-neutral-700 text-xs text-white focus:outline-none focus:border-cyan-400"
                  />
                </div>

                {/* Font & Alignment */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="text-xs font-bold text-neutral-400 block mb-1">
                      {lang === 'ka' ? 'ფონტი' : 'Font Family'}
                    </label>
                    <select
                      value={textOverlay.fontFamily}
                      onChange={(e) =>
                        setTextOverlay((prev) => ({
                          ...prev,
                          fontFamily: e.target.value as any,
                        }))
                      }
                      className="w-full px-3 py-2 rounded-xl bg-neutral-800 border border-neutral-700 text-xs text-white focus:outline-none focus:border-cyan-400"
                    >
                      <option value="Outfit">Outfit (Modern Display)</option>
                      <option value="Syne">Syne (Bold Futuristic)</option>
                      <option value="Plus Jakarta Sans">Plus Jakarta Sans (Clean)</option>
                      <option value="JetBrains Mono">JetBrains Mono (Tech Code)</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs font-bold text-neutral-400 block mb-1">
                      {lang === 'ka' ? 'განლაგება' : 'Alignment'}
                    </label>
                    <div className="grid grid-cols-3 gap-1 bg-neutral-800 p-1 rounded-xl border border-neutral-700">
                      {['left', 'center', 'right'].map((align) => (
                        <button
                          key={align}
                          onClick={() =>
                            setTextOverlay((prev) => ({
                              ...prev,
                              alignment: align as 'left' | 'center' | 'right',
                            }))
                          }
                          className={`py-1 rounded-lg text-xs font-semibold uppercase transition-all ${
                            textOverlay.alignment === align
                              ? 'bg-cyan-500 text-neutral-950 font-bold'
                              : 'text-neutral-400 hover:text-white'
                          }`}
                        >
                          {align}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Timecode & Watermark Toggles */}
                <div className="grid grid-cols-2 gap-3">
                  <label className="flex items-center gap-2 p-2.5 rounded-xl bg-neutral-800/40 border border-neutral-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={textOverlay.showTimestamp}
                      onChange={(e) =>
                        setTextOverlay((prev) => ({ ...prev, showTimestamp: e.target.checked }))
                      }
                      className="w-4 h-4 accent-cyan-400 rounded"
                    />
                    <span className="text-xs font-medium text-neutral-300">
                      {lang === 'ka' ? 'თაიმკოდის ჩვენება' : 'Show Timecode'}
                    </span>
                  </label>

                  <label className="flex items-center gap-2 p-2.5 rounded-xl bg-neutral-800/40 border border-neutral-800 cursor-pointer">
                    <input
                      type="checkbox"
                      checked={textOverlay.showWatermark}
                      onChange={(e) =>
                        setTextOverlay((prev) => ({ ...prev, showWatermark: e.target.checked }))
                      }
                      className="w-4 h-4 accent-cyan-400 rounded"
                    />
                    <span className="text-xs font-medium text-neutral-300">
                      {lang === 'ka' ? 'ვოთერმარკი (Watermark)' : 'Show Watermark'}
                    </span>
                  </label>
                </div>
              </>
            )}
          </div>
        )}

        {/* 6. Effects Tab (ეფექტები) */}
        {activeTab === 'effects' && (
          <div className="space-y-4">
            {/* Particles Toggle & Settings */}
            <div className="bg-neutral-800/40 p-3.5 rounded-xl border border-neutral-800 space-y-3">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-neutral-200 block">
                    {lang === 'ka' ? 'მოძრავი ნაწილაკები (Particles)' : 'Floating Particle System'}
                  </span>
                  <span className="text-[11px] text-neutral-400">
                    {lang === 'ka' ? 'ვარსკვლავები და ნაპერწკლები' : 'Audio-reactive starfield and sparks'}
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={effects.particlesEnabled}
                  onChange={(e) =>
                    setEffects((prev) => ({ ...prev, particlesEnabled: e.target.checked }))
                  }
                  className="w-5 h-5 accent-cyan-400 rounded cursor-pointer"
                />
              </div>

              {effects.particlesEnabled && (
                <div className="grid grid-cols-2 gap-3 pt-2 border-t border-neutral-700/50">
                  <div>
                    <label className="text-xs text-neutral-400 block mb-1">
                      {lang === 'ka' ? 'ტიპი' : 'Particle Type'}
                    </label>
                    <select
                      value={effects.particleType}
                      onChange={(e) =>
                        setEffects((prev) => ({ ...prev, particleType: e.target.value as any }))
                      }
                      className="w-full px-2 py-1.5 rounded-lg bg-neutral-800 border border-neutral-700 text-xs text-white"
                    >
                      <option value="stars">Stars / Space</option>
                      <option value="fireflies">Fireflies / Glowing</option>
                      <option value="dust">Ambient Dust</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-xs text-neutral-400 block mb-1">
                      {lang === 'ka' ? 'რაოდენობა' : 'Count'} ({effects.particleCount})
                    </label>
                    <input
                      type="range"
                      min={20}
                      max={150}
                      step={10}
                      value={effects.particleCount}
                      onChange={(e) =>
                        setEffects((prev) => ({ ...prev, particleCount: parseInt(e.target.value) }))
                      }
                      className="w-full accent-cyan-400 h-1.5 bg-neutral-700 rounded-lg"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Other Visual Effects */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <label className="flex items-center justify-between p-3 rounded-xl bg-neutral-800/40 border border-neutral-800 cursor-pointer">
                <div>
                  <span className="text-xs font-bold text-neutral-200 block">
                    {lang === 'ka' ? 'ბასის დარტყმითი ტალღა' : 'Bass Shockwave'}
                  </span>
                  <span className="text-[11px] text-neutral-400">
                    {lang === 'ka' ? 'რადიალური ტალღა დარტყმაზე' : 'Ripple on heavy kicks'}
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={effects.bassShockwave}
                  onChange={(e) =>
                    setEffects((prev) => ({ ...prev, bassShockwave: e.target.checked }))
                  }
                  className="w-4 h-4 accent-cyan-400 rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl bg-neutral-800/40 border border-neutral-800 cursor-pointer">
                <div>
                  <span className="text-xs font-bold text-neutral-200 block">
                    {lang === 'ka' ? 'CRT სკანლაინები' : 'CRT Scanlines'}
                  </span>
                  <span className="text-[11px] text-neutral-400">
                    {lang === 'ka' ? 'რეტრო ეკრანის ხაზები' : 'Retro monitor lines'}
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={effects.scanlines}
                  onChange={(e) =>
                    setEffects((prev) => ({ ...prev, scanlines: e.target.checked }))
                  }
                  className="w-4 h-4 accent-cyan-400 rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl bg-neutral-800/40 border border-neutral-800 cursor-pointer">
                <div>
                  <span className="text-xs font-bold text-neutral-200 block">
                    {lang === 'ka' ? 'ვინიეტა (Vignette)' : 'Vignette Shadows'}
                  </span>
                  <span className="text-[11px] text-neutral-400">
                    {lang === 'ka' ? 'ჩაბნელებული კუთხეები' : 'Cinematic corner darkening'}
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={effects.vignette}
                  onChange={(e) =>
                    setEffects((prev) => ({ ...prev, vignette: e.target.checked }))
                  }
                  className="w-4 h-4 accent-cyan-400 rounded"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl bg-neutral-800/40 border border-neutral-800 cursor-pointer">
                <div>
                  <span className="text-xs font-bold text-neutral-200 block">
                    {lang === 'ka' ? 'ბიტის ციმციმი' : 'Beat Flash'}
                  </span>
                  <span className="text-[11px] text-neutral-400">
                    {lang === 'ka' ? 'მსუბუქი განათება ბიტზე' : 'Subtle glow on peak'}
                  </span>
                </div>
                <input
                  type="checkbox"
                  checked={effects.beatFlash}
                  onChange={(e) =>
                    setEffects((prev) => ({ ...prev, beatFlash: e.target.checked }))
                  }
                  className="w-4 h-4 accent-cyan-400 rounded"
                />
              </label>
            </div>
          </div>
        )}

        {/* 7. Save & Export Tab (დასეივება / ექსპორტი) */}
        {activeTab === 'export' && (
          <div className="space-y-5">
            {/* Professional Video Export Engine */}
            <div className="p-4 rounded-2xl bg-gradient-to-r from-fuchsia-950/40 via-neutral-900 to-cyan-950/40 border border-fuchsia-500/30 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-fuchsia-500/20 text-fuchsia-400 flex items-center justify-center">
                    <Film className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="text-sm font-bold text-white flex items-center gap-2">
                      <span>{lang === 'ka' ? 'სტუდიური ვიდეო რენდერი (Studio Master)' : 'Studio Master Video Renderer'}</span>
                    </h4>
                    <p className="text-xs text-neutral-400">
                      {lang === 'ka'
                        ? '60 FPS / 4K Ultra ხარისხი, სუფთა აუდიო, 100% ვოთერმარკის გარეშე'
                        : '60 FPS Master Video, 18-30 Mbps Bitrate, 100% Watermark-Free'}
                    </p>
                  </div>
                </div>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 whitespace-nowrap">
                  {lang === 'ka' ? 'ვოთერმარკის გარეშე' : 'NO WATERMARK'}
                </span>
              </div>

              {isRecording ? (
                <div className="flex items-center justify-between gap-3 p-3 bg-red-950/50 border border-red-500/40 rounded-xl animate-pulse">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-red-500 animate-ping" />
                    <span className="text-xs font-mono font-bold text-red-300">
                      {lang === 'ka' ? 'მიმდინარეობს პირდაპირი რენდერი:' : 'Master Rendering:'}{' '}
                      {recordingProgress}s
                    </span>
                  </div>
                  <button
                    onClick={onStopVideoRecording}
                    className="px-4 py-2 rounded-xl bg-red-500 hover:bg-red-400 text-white text-xs font-bold transition-all shadow-lg shadow-red-500/30 cursor-pointer"
                  >
                    {lang === 'ka' ? 'დასრულება და შენახვა' : 'Finish & Save Master Video'}
                  </button>
                </div>
              ) : (
                <button
                  onClick={onStartVideoRecording}
                  className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-fuchsia-500 via-pink-500 to-cyan-400 text-neutral-950 text-xs font-black shadow-lg shadow-fuchsia-500/20 hover:brightness-110 active:scale-[0.99] transition-all cursor-pointer"
                >
                  <Film className="w-4 h-4" />
                  <span>{lang === 'ka' ? 'სტუდიური ვიდეო ექსპორტის დაწყება' : 'Start Studio Video Master Export'}</span>
                </button>
              )}
            </div>

            {/* High-Res Snapshot & Waveform Image */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                onClick={() => onCaptureSnapshot(false)}
                className="flex items-center justify-center gap-2 p-3.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-100 text-xs font-bold transition-all cursor-pointer"
              >
                <Camera className="w-4 h-4 text-cyan-400" />
                <span>{lang === 'ka' ? 'სრული კადრის შენახვა (PNG)' : 'Download Frame (PNG)'}</span>
              </button>

              <button
                onClick={() => onCaptureSnapshot(true)}
                className="flex items-center justify-center gap-2 p-3.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-100 text-xs font-bold transition-all cursor-pointer"
              >
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>
                  {lang === 'ka' ? 'გამჭვირვალე ტალღა (Alpha PNG)' : 'Transparent Waveform (Alpha PNG)'}
                </span>
              </button>
            </div>

            {/* Preset Export / Import JSON */}
            <div className="p-3.5 rounded-xl bg-neutral-800/40 border border-neutral-800 space-y-2.5">
              <span className="text-xs font-bold text-neutral-300 block">
                {lang === 'ka' ? 'პრესეტის შენახვა / ჩატვირთვა (JSON)' : 'Preset Configuration Backup'}
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={handleExportJSON}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-xs font-semibold text-neutral-200 transition-all"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>{lang === 'ka' ? 'პრესეტის ექსპორტი' : 'Export Preset JSON'}</span>
                </button>

                <input
                  ref={jsonImportRef}
                  type="file"
                  accept=".json"
                  className="hidden"
                  onChange={handleImportJSON}
                />
                <button
                  onClick={() => jsonImportRef.current?.click()}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-xs font-semibold text-neutral-200 transition-all"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>{lang === 'ka' ? 'პრესეტის იმპორტი' : 'Import Preset JSON'}</span>
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
