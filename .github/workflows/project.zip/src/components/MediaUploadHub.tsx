import React, { useRef, useState } from 'react';
import {
  Upload,
  Music,
  Image as ImageIcon,
  Disc,
  CheckCircle2,
  Trash2,
  Sparkles,
  FileAudio,
  Layers,
  ArrowRight,
} from 'lucide-react';
import { AudioTrackInfo, BackgroundConfig, CenterArtConfig, TextOverlayConfig } from '../types';
import { audioEngine } from '../utils/audioEngine';
import confetti from 'canvas-confetti';

interface MediaUploadHubProps {
  onAudioUploaded: (track: AudioTrackInfo) => void;
  currentTrack: AudioTrackInfo;
  background: BackgroundConfig;
  onBackgroundChange: (bg: Partial<BackgroundConfig>) => void;
  centerArt: CenterArtConfig;
  onCenterArtChange: (art: Partial<CenterArtConfig>) => void;
  onTextOverlayChange: (text: Partial<TextOverlayConfig>) => void;
  lang: 'en' | 'ka';
}

export const MediaUploadHub: React.FC<MediaUploadHubProps> = ({
  onAudioUploaded,
  currentTrack,
  background,
  onBackgroundChange,
  centerArt,
  onCenterArtChange,
  onTextOverlayChange,
  lang,
}) => {
  const audioInputRef = useRef<HTMLInputElement | null>(null);
  const bgImageInputRef = useRef<HTMLInputElement | null>(null);
  const centerImageInputRef = useRef<HTMLInputElement | null>(null);

  const [audioDragOver, setAudioDragOver] = useState(false);
  const [imageDragOver, setImageDragOver] = useState(false);
  const [centerDragOver, setCenterDragOver] = useState(false);

  const t = {
    title: lang === 'ka' ? 'ჩემი მედიის ატვირთვა' : 'Upload My Media',
    subtitle:
      lang === 'ka'
        ? 'ატვირთეთ თქვენი საკუთარი სიმღერა (MP3/WAV) და ფოტო (JPG/PNG)'
        : 'Upload your own song (MP3/WAV) and custom image (JPG/PNG)',
    uploadMusic: lang === 'ka' ? 'სიმღერის / აუდიოს ატვირთვა' : 'Upload Music / Audio',
    uploadMusicSub: lang === 'ka' ? 'MP3, WAV, FLAC, M4A, OGG' : 'Supports MP3, WAV, FLAC, M4A',
    uploadBg: lang === 'ka' ? 'ფონის სურათის ატვირთვა' : 'Upload Background Photo',
    uploadBgSub: lang === 'ka' ? 'მაღალი ხარისხის ფონი (HD/4K)' : 'High-Res Wallpaper (JPG/PNG)',
    uploadCenter: lang === 'ka' ? 'ცენტრის ლოგო / ქავერი' : 'Upload Center Art / Logo',
    uploadCenterSub: lang === 'ka' ? 'ალბომის ქავერი ან ავატარი' : 'Album Art or Badge',
    dropHere: lang === 'ka' ? 'ჩააგდეთ ფაილი აქ' : 'Drop file here',
    activeTrack: lang === 'ka' ? 'აქტიური სიმღერა' : 'Active Song',
    activeBg: lang === 'ka' ? 'აქტიური ფონი' : 'Active Background',
    activeCover: lang === 'ka' ? 'აქტიური ქავერი' : 'Active Cover',
    useAsBoth: lang === 'ka' ? 'გამოიყენე ფონადაც და ქავერადაც' : 'Use as both BG and Cover',
    remove: lang === 'ka' ? 'წაშლა' : 'Remove',
    chooseFile: lang === 'ka' ? 'ფაილის არჩევა' : 'Browse File',
  };

  // Handle audio file selection
  const processAudioFile = async (file: File) => {
    if (!file) return;
    try {
      const res = await audioEngine.loadAudioFile(file);
      const cleanedTitle = file.name.replace(/\.[^/.]+$/, '').replace(/^[0-9\s._-]+/, '');
      
      const newTrack: AudioTrackInfo = {
        id: 'uploaded-' + Date.now(),
        title: cleanedTitle || file.name,
        artist: 'Master Audio Track',
        source: 'upload',
        duration: res.duration || 180,
      };

      onAudioUploaded(newTrack);
      
      // Also update text overlay with song title automatically
      onTextOverlayChange({
        title: cleanedTitle.toUpperCase(),
        artist: 'SONNA RELE (HONOR BRAND SONG)',
      });

      audioEngine.play();
      confetti({ particleCount: 50, spread: 60 });
    } catch (err) {
      console.error('Failed to load audio file:', err);
    }
  };

  // Handle background image selection
  const processBgImage = (file: File) => {
    if (!file) return;
    const url = URL.createObjectURL(file);
    onBackgroundChange({
      type: 'image',
      imageUrl: url,
    });
    confetti({ particleCount: 40, spread: 50 });
  };

  // Handle center cover image selection
  const processCenterImage = (file: File) => {
    if (!file) return;
    const url = URL.createObjectURL(file);
    onCenterArtChange({
      shape: centerArt.shape === 'none' ? 'circle' : centerArt.shape,
      imageUrl: url,
    });
    confetti({ particleCount: 40, spread: 50 });
  };

  return (
    <div className="w-full bg-neutral-900/90 border border-neutral-800/90 rounded-2xl p-4 sm:p-5 shadow-2xl backdrop-blur-xl flex flex-col gap-4">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-neutral-800 pb-3">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-cyan-500/20 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Upload className="w-4 h-4" />
          </div>
          <div>
            <h2 className="text-sm sm:text-base font-bold text-white flex items-center gap-2">
              <span>{t.title}</span>
              <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-md bg-gradient-to-r from-cyan-500/20 to-fuchsia-500/20 text-cyan-300 border border-cyan-500/30">
                DRAG & DROP
              </span>
            </h2>
            <p className="text-xs text-neutral-400">{t.subtitle}</p>
          </div>
        </div>
      </div>

      {/* 3 Interactive Upload Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-3.5">
        {/* 1. MUSIC UPLOAD CARD */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setAudioDragOver(true);
          }}
          onDragLeave={() => setAudioDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setAudioDragOver(false);
            const file = e.dataTransfer.files?.[0];
            if (file && (file.type.startsWith('audio/') || file.name.match(/\.(mp3|wav|flac|m4a|ogg|aac)$/i))) {
              processAudioFile(file);
            }
          }}
          className={`relative group flex flex-col justify-between p-3.5 rounded-xl border transition-all duration-200 cursor-pointer ${
            audioDragOver
              ? 'bg-cyan-500/20 border-cyan-400 shadow-lg shadow-cyan-500/20 scale-[1.02]'
              : currentTrack.source === 'upload'
              ? 'bg-gradient-to-b from-cyan-950/40 to-neutral-900 border-cyan-500/50 shadow-md'
              : 'bg-neutral-950/60 hover:bg-neutral-800/60 border-neutral-800 hover:border-cyan-500/40'
          }`}
          onClick={() => audioInputRef.current?.click()}
        >
          <input
            ref={audioInputRef}
            type="file"
            accept="audio/*,.mp3,.wav,.flac,.m4a,.ogg,.aac,.opus"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) processAudioFile(file);
            }}
          />

          <div className="flex items-start justify-between gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-sky-500 p-0.5 flex-shrink-0 shadow-md shadow-cyan-500/20">
              <div className="w-full h-full bg-neutral-950 rounded-[10px] flex items-center justify-center text-cyan-400">
                <Music className="w-5 h-5" />
              </div>
            </div>
            {currentTrack.source === 'upload' ? (
              <span className="flex items-center gap-1 text-[10px] font-bold text-cyan-300 bg-cyan-500/20 px-2 py-0.5 rounded-md border border-cyan-500/30">
                <CheckCircle2 className="w-3 h-3" />
                {t.activeTrack}
              </span>
            ) : (
              <span className="text-[10px] font-semibold text-neutral-400 group-hover:text-cyan-300 transition-colors">
                {t.chooseFile}
              </span>
            )}
          </div>

          <div className="my-2">
            <h3 className="text-xs sm:text-sm font-bold text-white truncate">
              {currentTrack.source === 'upload' ? currentTrack.title : t.uploadMusic}
            </h3>
            <p className="text-[11px] text-neutral-400 truncate">
              {currentTrack.source === 'upload' ? '▶ დაკვრის რეჟიმშია' : t.uploadMusicSub}
            </p>
          </div>

          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              audioInputRef.current?.click();
            }}
            className="w-full py-1.5 px-3 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/40 text-cyan-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
          >
            <Upload className="w-3.5 h-3.5" />
            <span>{currentTrack.source === 'upload' ? (lang === 'ka' ? 'სხვა სიმღერა' : 'Change Audio') : t.uploadMusic}</span>
          </button>
        </div>

        {/* 2. BACKGROUND PHOTO UPLOAD CARD */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setImageDragOver(true);
          }}
          onDragLeave={() => setImageDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setImageDragOver(false);
            const file = e.dataTransfer.files?.[0];
            if (file && (file.type.startsWith('image/') || file.name.match(/\.(jpg|jpeg|png|webp|gif|svg)$/i))) {
              processBgImage(file);
            }
          }}
          className={`relative group flex flex-col justify-between p-3.5 rounded-xl border transition-all duration-200 cursor-pointer ${
            imageDragOver
              ? 'bg-fuchsia-500/20 border-fuchsia-400 shadow-lg shadow-fuchsia-500/20 scale-[1.02]'
              : background.type === 'image' && background.imageUrl
              ? 'bg-gradient-to-b from-fuchsia-950/40 to-neutral-900 border-fuchsia-500/50 shadow-md'
              : 'bg-neutral-950/60 hover:bg-neutral-800/60 border-neutral-800 hover:border-fuchsia-500/40'
          }`}
          onClick={() => bgImageInputRef.current?.click()}
        >
          <input
            ref={bgImageInputRef}
            type="file"
            accept="image/*,.jpg,.jpeg,.png,.webp,.gif,.svg"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) processBgImage(file);
            }}
          />

          <div className="flex items-start justify-between gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-fuchsia-500 to-pink-500 p-0.5 flex-shrink-0 shadow-md shadow-fuchsia-500/20">
              <div className="w-full h-full bg-neutral-950 rounded-[10px] flex items-center justify-center text-fuchsia-400 overflow-hidden">
                {background.type === 'image' && background.imageUrl ? (
                  <img
                    src={background.imageUrl}
                    alt="Background"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <ImageIcon className="w-5 h-5" />
                )}
              </div>
            </div>
            {background.type === 'image' && background.imageUrl ? (
              <span className="flex items-center gap-1 text-[10px] font-bold text-fuchsia-300 bg-fuchsia-500/20 px-2 py-0.5 rounded-md border border-fuchsia-500/30">
                <CheckCircle2 className="w-3 h-3" />
                {t.activeBg}
              </span>
            ) : (
              <span className="text-[10px] font-semibold text-neutral-400 group-hover:text-fuchsia-300 transition-colors">
                {t.chooseFile}
              </span>
            )}
          </div>

          <div className="my-2">
            <h3 className="text-xs sm:text-sm font-bold text-white truncate">
              {t.uploadBg}
            </h3>
            <p className="text-[11px] text-neutral-400 truncate">{t.uploadBgSub}</p>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                bgImageInputRef.current?.click();
              }}
              className="flex-1 py-1.5 px-3 rounded-lg bg-fuchsia-500/20 hover:bg-fuchsia-500/30 border border-fuchsia-500/40 text-fuchsia-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>{background.imageUrl ? (lang === 'ka' ? 'შეცვლა' : 'Change') : t.chooseFile}</span>
            </button>

            {background.imageUrl && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onBackgroundChange({ imageUrl: '', type: 'gradient' });
                }}
                className="p-1.5 rounded-lg bg-neutral-800 hover:bg-red-500/20 hover:text-red-400 border border-neutral-700 text-neutral-400 text-xs transition-colors"
                title={t.remove}
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* 3. CENTER COVER / LOGO UPLOAD CARD */}
        <div
          onDragOver={(e) => {
            e.preventDefault();
            setCenterDragOver(true);
          }}
          onDragLeave={() => setCenterDragOver(false)}
          onDrop={(e) => {
            e.preventDefault();
            setCenterDragOver(false);
            const file = e.dataTransfer.files?.[0];
            if (file && (file.type.startsWith('image/') || file.name.match(/\.(jpg|jpeg|png|webp|gif|svg)$/i))) {
              processCenterImage(file);
            }
          }}
          className={`relative group flex flex-col justify-between p-3.5 rounded-xl border transition-all duration-200 cursor-pointer ${
            centerDragOver
              ? 'bg-amber-500/20 border-amber-400 shadow-lg shadow-amber-500/20 scale-[1.02]'
              : centerArt.imageUrl
              ? 'bg-gradient-to-b from-amber-950/40 to-neutral-900 border-amber-500/50 shadow-md'
              : 'bg-neutral-950/60 hover:bg-neutral-800/60 border-neutral-800 hover:border-amber-500/40'
          }`}
          onClick={() => centerImageInputRef.current?.click()}
        >
          <input
            ref={centerImageInputRef}
            type="file"
            accept="image/*,.jpg,.jpeg,.png,.webp,.gif,.svg"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) processCenterImage(file);
            }}
          />

          <div className="flex items-start justify-between gap-2">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-amber-500 to-orange-500 p-0.5 flex-shrink-0 shadow-md shadow-amber-500/20">
              <div className="w-full h-full bg-neutral-950 rounded-[10px] flex items-center justify-center text-amber-400 overflow-hidden">
                {centerArt.imageUrl ? (
                  <img
                    src={centerArt.imageUrl}
                    alt="Center Cover"
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover rounded-full"
                  />
                ) : (
                  <Disc className="w-5 h-5" />
                )}
              </div>
            </div>
            {centerArt.imageUrl ? (
              <span className="flex items-center gap-1 text-[10px] font-bold text-amber-300 bg-amber-500/20 px-2 py-0.5 rounded-md border border-amber-500/30">
                <CheckCircle2 className="w-3 h-3" />
                {t.activeCover}
              </span>
            ) : (
              <span className="text-[10px] font-semibold text-neutral-400 group-hover:text-amber-300 transition-colors">
                {t.chooseFile}
              </span>
            )}
          </div>

          <div className="my-2">
            <h3 className="text-xs sm:text-sm font-bold text-white truncate">
              {t.uploadCenter}
            </h3>
            <p className="text-[11px] text-neutral-400 truncate">{t.uploadCenterSub}</p>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={(e) => {
                e.stopPropagation();
                centerImageInputRef.current?.click();
              }}
              className="flex-1 py-1.5 px-3 rounded-lg bg-amber-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-200 text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
            >
              <Upload className="w-3.5 h-3.5" />
              <span>{centerArt.imageUrl ? (lang === 'ka' ? 'შეცვლა' : 'Change') : t.chooseFile}</span>
            </button>

            {centerArt.imageUrl && (
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  onCenterArtChange({ imageUrl: '' });
                }}
                className="p-1.5 rounded-lg bg-neutral-800 hover:bg-red-500/20 hover:text-red-400 border border-neutral-700 text-neutral-400 text-xs transition-colors"
                title={t.remove}
              >
                <Trash2 className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
