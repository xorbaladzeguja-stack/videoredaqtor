import React, { useRef } from 'react';
import {
  Activity,
  Layers,
  Ratio,
  Globe,
  Sparkles,
  Camera,
  Film,
  Maximize2,
  Music,
  Image as ImageIcon,
  Upload,
} from 'lucide-react';
import { AspectRatioType, VisualizerPreset } from '../types';
import { VISUALIZER_PRESETS } from '../utils/presets';

interface HeaderProps {
  currentPresetId: string;
  onSelectPreset: (preset: VisualizerPreset) => void;
  aspectRatio: AspectRatioType;
  onSelectAspectRatio: (ratio: AspectRatioType) => void;
  onCaptureSnapshot: () => void;
  onRecordVideo: () => void;
  isRecording: boolean;
  lang: 'en' | 'ka';
  onToggleLang: () => void;
  onQuickUploadMusic?: (file: File) => void;
  onQuickUploadImage?: (file: File) => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentPresetId,
  onSelectPreset,
  aspectRatio,
  onSelectAspectRatio,
  onCaptureSnapshot,
  onRecordVideo,
  isRecording,
  lang,
  onToggleLang,
  onQuickUploadMusic,
  onQuickUploadImage,
}) => {
  const musicInputRef = useRef<HTMLInputElement | null>(null);
  const imageInputRef = useRef<HTMLInputElement | null>(null);

  const aspectRatios: { id: AspectRatioType; label: string; desc: string }[] = [
    { id: '16:9', label: '16:9', desc: 'Landscape / YouTube' },
    { id: '9:16', label: '9:16', desc: 'Vertical / TikTok & Reels' },
    { id: '1:1', label: '1:1', desc: 'Square / Instagram' },
    { id: '4:3', label: '4:3', desc: 'Classic Standard' },
  ];

  return (
    <header className="w-full flex flex-col md:flex-row items-center justify-between gap-4 py-4 px-4 sm:px-6 bg-neutral-900/60 border-b border-neutral-800/80 backdrop-blur-xl sticky top-0 z-40">
      {/* Brand Title */}
      <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
        <div className="flex items-center gap-3">
          <div className="relative w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 via-sky-500 to-fuchsia-500 p-0.5 shadow-lg shadow-cyan-500/25">
            <div className="w-full h-full bg-neutral-950 rounded-[10px] flex items-center justify-center text-cyan-400">
              <Activity className="w-5 h-5 animate-pulse" />
            </div>
          </div>

          <div>
            <h1 className="text-base sm:text-lg font-black tracking-tight text-white flex items-center gap-2">
              <span>WAVEFORM STUDIO</span>
              <span className="text-[10px] font-bold px-1.5 py-0.5 rounded-md bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                PRO 4K
              </span>
            </h1>
            <p className="text-xs text-neutral-400">
              {lang === 'ka'
                ? 'ანიმაციური აუდიო ტალღები და ვიზუალიზატორი'
                : 'Animated Audio Waveform & Visualizer Generator'}
            </p>
          </div>
        </div>

        {/* Quick Upload Buttons for Mobile */}
        <div className="md:hidden flex items-center gap-1.5">
          <button
            onClick={() => musicInputRef.current?.click()}
            className="p-2 rounded-xl bg-cyan-500/20 border border-cyan-500/30 text-cyan-300"
            title="ატვირთე მუსიკა"
          >
            <Music className="w-4 h-4" />
          </button>
          <button
            onClick={() => imageInputRef.current?.click()}
            className="p-2 rounded-xl bg-fuchsia-500/20 border border-fuchsia-500/30 text-fuchsia-300"
            title="ატვირთე ფოტო"
          >
            <ImageIcon className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Hidden Inputs for Header Uploads */}
      <input
        ref={musicInputRef}
        type="file"
        accept="audio/*,.mp3,.wav,.flac,.m4a,.ogg,.aac"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file && onQuickUploadMusic) onQuickUploadMusic(file);
        }}
      />
      <input
        ref={imageInputRef}
        type="file"
        accept="image/*,.jpg,.jpeg,.png,.webp"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file && onQuickUploadImage) onQuickUploadImage(file);
        }}
      />

      {/* Preset Selector, Upload Shortcuts & Aspect Ratio Bar */}
      <div className="flex items-center gap-2 sm:gap-2.5 flex-wrap w-full md:w-auto justify-center md:justify-end">
        {/* Quick Direct Upload Buttons */}
        <button
          onClick={() => musicInputRef.current?.click()}
          className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/40 text-cyan-300 text-xs font-bold transition-all shadow-sm active:scale-95"
          title={lang === 'ka' ? 'სიმღერის / აუდიოს ატვირთვა' : 'Upload Music'}
        >
          <Music className="w-3.5 h-3.5" />
          <span>{lang === 'ka' ? 'მუსიკის ატვირთვა' : 'Upload Music'}</span>
        </button>

        <button
          onClick={() => imageInputRef.current?.click()}
          className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-fuchsia-500/15 hover:bg-fuchsia-500/25 border border-fuchsia-500/40 text-fuchsia-300 text-xs font-bold transition-all shadow-sm active:scale-95"
          title={lang === 'ka' ? 'ფოტოს ატვირთვა' : 'Upload Photo'}
        >
          <ImageIcon className="w-3.5 h-3.5" />
          <span>{lang === 'ka' ? 'ფოტოს ატვირთვა' : 'Upload Photo'}</span>
        </button>

        {/* Visualizer Preset Dropdown */}
        <div className="flex items-center bg-neutral-800/80 border border-neutral-700/80 rounded-xl px-2 py-1">
          <Layers className="w-3.5 h-3.5 text-cyan-400 mr-1.5" />
          <select
            value={currentPresetId}
            onChange={(e) => {
              const preset = VISUALIZER_PRESETS.find((p) => p.id === e.target.value);
              if (preset) onSelectPreset(preset);
            }}
            className="bg-transparent text-xs font-semibold text-neutral-200 focus:outline-none cursor-pointer pr-2"
          >
            {VISUALIZER_PRESETS.map((p) => (
              <option key={p.id} value={p.id} className="bg-neutral-900 text-white">
                {lang === 'ka' && p.nameKa ? p.nameKa : p.name}
              </option>
            ))}
          </select>
        </div>

        {/* Aspect Ratio Buttons */}
        <div className="flex items-center bg-neutral-800/80 border border-neutral-700/80 rounded-xl p-0.5">
          {aspectRatios.map((r) => (
            <button
              key={r.id}
              onClick={() => onSelectAspectRatio(r.id)}
              className={`px-2.5 py-1 rounded-lg text-xs font-semibold transition-all ${
                aspectRatio === r.id
                  ? 'bg-cyan-500 text-neutral-950 font-bold shadow-sm'
                  : 'text-neutral-400 hover:text-white'
              }`}
              title={r.desc}
            >
              {r.label}
            </button>
          ))}
        </div>

        {/* Quick Snapshot Action */}
        <button
          onClick={onCaptureSnapshot}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 border border-neutral-700 text-neutral-200 text-xs font-semibold transition-all shadow-sm"
          title={lang === 'ka' ? 'კადრის შენახვა (PNG)' : 'Download PNG Snapshot'}
        >
          <Camera className="w-3.5 h-3.5 text-cyan-400" />
          <span className="hidden sm:inline">{lang === 'ka' ? 'კადრი' : 'Snapshot'}</span>
        </button>

        {/* Quick Video Record Action */}
        <button
          onClick={onRecordVideo}
          className={`flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl text-xs font-bold transition-all shadow-md ${
            isRecording
              ? 'bg-red-500 text-white animate-pulse shadow-red-500/30'
              : 'bg-gradient-to-r from-cyan-500 to-fuchsia-500 text-neutral-950 shadow-cyan-500/20 hover:scale-105 active:scale-95'
          }`}
          title={lang === 'ka' ? 'ვიდეოს ექსპორტი' : 'Export Video'}
        >
          <Film className="w-3.5 h-3.5" />
          <span>{isRecording ? (lang === 'ka' ? 'იწერება...' : 'Recording...') : lang === 'ka' ? 'ვიდეო' : 'Export'}</span>
        </button>

        {/* Language Switcher */}
        <button
          onClick={onToggleLang}
          className="flex items-center gap-1 px-2.5 py-1.5 rounded-xl bg-neutral-800/80 hover:bg-neutral-700/80 border border-neutral-700 text-neutral-300 text-xs font-semibold transition-all"
        >
          <Globe className="w-3.5 h-3.5 text-cyan-400" />
          <span>{lang === 'ka' ? 'GE' : 'EN'}</span>
        </button>
      </div>
    </header>
  );
};
