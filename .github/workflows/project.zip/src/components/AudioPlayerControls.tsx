import React, { useRef, useState } from 'react';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  Upload,
  Mic,
  MicOff,
  RotateCcw,
  Repeat,
  Music,
  Radio,
  Sparkles,
} from 'lucide-react';
import { audioEngine } from '../utils/audioEngine';
import { AudioTrackInfo } from '../types';

interface AudioPlayerControlsProps {
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  currentTrack: AudioTrackInfo;
  isMicActive: boolean;
  onTrackChange: (track: AudioTrackInfo) => void;
  onPlayToggle: () => void;
  lang: 'en' | 'ka';
}

export const AudioPlayerControls: React.FC<AudioPlayerControlsProps> = ({
  isPlaying,
  currentTime,
  duration,
  currentTrack,
  isMicActive,
  onTrackChange,
  onPlayToggle,
  lang,
}) => {
  const [volume, setVolume] = useState<number>(0.9);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isLooping, setIsLooping] = useState<boolean>(true);
  const fileInputRef = useRef<HTMLInputElement | null>(null);

  const t = {
    play: lang === 'ka' ? 'დაკვრა' : 'Play',
    pause: lang === 'ka' ? 'პაუზა' : 'Pause',
    uploadAudio: lang === 'ka' ? 'აუდიოს ატვირთვა' : 'Upload Audio',
    micLive: lang === 'ka' ? 'მიკროფონი' : 'Live Mic',
    synthTracks: lang === 'ka' ? 'სინთეზატორის ბიტები' : 'Procedural Beats',
    customTrack: lang === 'ka' ? 'ატვირთული მუსიკა' : 'Uploaded Track',
    loop: lang === 'ka' ? 'გამეორება' : 'Loop',
    volume: lang === 'ka' ? 'ხმა' : 'Volume',
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs) || secs < 0) return '00:00';
    const m = Math.floor(secs / 60);
    const s = Math.floor(secs % 60);
    return `${m < 10 ? '0' : ''}${m}:${s < 10 ? '0' : ''}${s}`;
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = parseFloat(e.target.value);
    setVolume(val);
    setIsMuted(val === 0);
    audioEngine.setVolume(val);
  };

  const handleToggleMute = () => {
    if (isMuted) {
      setIsMuted(false);
      audioEngine.setVolume(volume || 0.8);
    } else {
      setIsMuted(true);
      audioEngine.setVolume(0);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = parseFloat(e.target.value);
    audioEngine.seek(time);
  };

  const handleToggleLoop = () => {
    const next = !isLooping;
    setIsLooping(next);
    audioEngine.setLoop(next);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const res = await audioEngine.loadAudioFile(file);
    const trackInfo: AudioTrackInfo = {
      id: 'custom-' + Date.now(),
      title: file.name.replace(/\.[^/.]+$/, ''),
      artist: 'Uploaded Audio',
      source: 'upload',
      duration: res.duration || 180,
    };
    onTrackChange(trackInfo);
    audioEngine.play();
  };

  const handleMicToggle = async () => {
    if (isMicActive) {
      audioEngine.stopMic();
      // Switch back to synth
      audioEngine.startSynthBeat('synthwave');
      onTrackChange({
        id: 'synth-synthwave',
        title: 'Neon Drive (Synthwave)',
        artist: 'Procedural Audio Engine',
        source: 'synth',
        duration: 180,
      });
    } else {
      const success = await audioEngine.startMic();
      if (success) {
        onTrackChange({
          id: 'live-mic',
          title: 'Live Microphone Input',
          artist: 'Realtime Audio Stream',
          source: 'mic',
          duration: 0,
        });
      }
    }
  };

  const handleSelectSynth = (genre: 'gobeyond' | 'synthwave' | 'cyberpunk' | 'lofi' | 'ambient') => {
    audioEngine.startSynthBeat(genre);
    const titles = {
      gobeyond: 'GO BEYOND (HONOR Anthem)',
      synthwave: 'Neon Drive (Synthwave 124 BPM)',
      cyberpunk: 'Cyber City (Electro 138 BPM)',
      lofi: 'Tokyo Night (Chill Lo-Fi 84 BPM)',
      ambient: 'Deep Space (Ambient Flow 100 BPM)',
    };
    const artists = {
      gobeyond: 'SONNA RELE (HONOR BRAND SONG)',
      synthwave: 'Procedural Audio Engine',
      cyberpunk: 'Procedural Audio Engine',
      lofi: 'Procedural Audio Engine',
      ambient: 'Procedural Audio Engine',
    };
    onTrackChange({
      id: `synth-${genre}`,
      title: titles[genre],
      artist: artists[genre],
      source: 'synth',
      duration: 210,
    });
  };

  const progressPercent = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <div className="w-full bg-neutral-900/90 border border-neutral-800 rounded-2xl p-3 sm:p-4 shadow-xl backdrop-blur-xl flex flex-col gap-3">
      {/* Track Info & Quick Switchers */}
      <div className="flex flex-wrap items-center justify-between gap-2 border-b border-neutral-800/80 pb-3">
        <div className="flex items-center gap-3 min-w-0">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-fuchsia-500 p-0.5 flex-shrink-0 shadow-lg shadow-cyan-500/20">
            <div className="w-full h-full bg-neutral-950 rounded-[10px] flex items-center justify-center text-cyan-400">
              {currentTrack.source === 'mic' ? (
                <Mic className="w-5 h-5 animate-pulse text-red-400" />
              ) : currentTrack.source === 'synth' ? (
                <Sparkles className="w-5 h-5 text-amber-400" />
              ) : (
                <Music className="w-5 h-5" />
              )}
            </div>
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-neutral-800 text-neutral-300 border border-neutral-700">
                {currentTrack.source === 'mic'
                  ? 'LIVE MIC'
                  : currentTrack.source === 'synth'
                  ? 'SYNTH BEAT'
                  : 'AUDIO FILE'}
              </span>
              <p className="text-sm font-bold text-white truncate max-w-[200px] sm:max-w-xs md:max-w-md">
                {currentTrack.title}
              </p>
            </div>
            <p className="text-xs text-neutral-400 truncate">{currentTrack.artist}</p>
          </div>
        </div>

        {/* Audio Source Quick Buttons */}
        <div className="flex items-center gap-1.5 sm:gap-2 flex-wrap">
          {/* File Upload */}
          <input
            ref={fileInputRef}
            type="file"
            accept="audio/*"
            className="hidden"
            onChange={handleFileUpload}
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-semibold transition-colors shadow-sm"
            title={t.uploadAudio}
          >
            <Upload className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">{t.uploadAudio}</span>
          </button>

          {/* Microphone Live */}
          <button
            onClick={handleMicToggle}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-semibold border transition-all ${
              isMicActive
                ? 'bg-red-500/20 text-red-300 border-red-500/50 shadow-md shadow-red-500/20 animate-pulse'
                : 'bg-neutral-800 hover:bg-neutral-700 text-neutral-300 border-neutral-700'
            }`}
            title={t.micLive}
          >
            {isMicActive ? <MicOff className="w-3.5 h-3.5 text-red-400" /> : <Mic className="w-3.5 h-3.5" />}
            <span className="hidden sm:inline">{t.micLive}</span>
          </button>

          {/* Synth Beat Options Dropdown/Group */}
          <div className="flex items-center bg-neutral-800/80 p-0.5 rounded-xl border border-neutral-700/60">
            <button
              onClick={() => handleSelectSynth('gobeyond')}
              className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                currentTrack.id === 'synth-gobeyond'
                  ? 'bg-gradient-to-r from-cyan-400 to-sky-400 text-neutral-950 font-black shadow-md shadow-cyan-500/30'
                  : 'text-cyan-300 hover:text-white hover:bg-neutral-700/50'
              }`}
            >
              ★ GO BEYOND (HONOR)
            </button>
            <button
              onClick={() => handleSelectSynth('synthwave')}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                currentTrack.id === 'synth-synthwave'
                  ? 'bg-cyan-500 text-black font-bold shadow-sm'
                  : 'text-neutral-300 hover:text-white'
              }`}
            >
              Synthwave
            </button>
            <button
              onClick={() => handleSelectSynth('cyberpunk')}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                currentTrack.id === 'synth-cyberpunk'
                  ? 'bg-fuchsia-500 text-black font-bold shadow-sm'
                  : 'text-neutral-300 hover:text-white'
              }`}
            >
              Cyberpunk
            </button>
            <button
              onClick={() => handleSelectSynth('lofi')}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-all ${
                currentTrack.id === 'synth-lofi'
                  ? 'bg-amber-500 text-black font-bold shadow-sm'
                  : 'text-neutral-300 hover:text-white'
              }`}
            >
              Lo-Fi
            </button>
          </div>
        </div>
      </div>

      {/* Progress Scrubber */}
      <div className="flex items-center gap-3">
        <span className="text-xs font-mono font-medium text-neutral-400 w-11 text-right">
          {formatTime(currentTime)}
        </span>

        <div className="relative flex-1 flex items-center h-4 group cursor-pointer">
          <div className="w-full h-1.5 bg-neutral-800 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-cyan-400 to-fuchsia-500 rounded-full transition-all duration-75"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
          <input
            type="range"
            min={0}
            max={duration || 100}
            step={0.1}
            value={currentTime}
            onChange={handleSeek}
            disabled={isMicActive}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer disabled:cursor-not-allowed"
          />
        </div>

        <span className="text-xs font-mono font-medium text-neutral-400 w-11">
          {formatTime(duration)}
        </span>
      </div>

      {/* Primary Playback Bar */}
      <div className="flex items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          {/* Loop toggle */}
          <button
            onClick={handleToggleLoop}
            className={`p-2 rounded-xl border transition-all ${
              isLooping
                ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/40'
                : 'bg-neutral-800/60 text-neutral-400 border-neutral-700 hover:text-white'
            }`}
            title={t.loop}
          >
            <Repeat className="w-4 h-4" />
          </button>

          {/* Restart from beginning */}
          <button
            onClick={() => audioEngine.seek(0)}
            className="p-2 rounded-xl bg-neutral-800/60 border border-neutral-700 text-neutral-300 hover:text-white hover:bg-neutral-700/80 transition-all"
            title="Restart Track"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>

        {/* Big Center Play / Pause Button */}
        <button
          onClick={onPlayToggle}
          className="flex items-center justify-center w-12 h-12 rounded-2xl bg-gradient-to-r from-cyan-500 via-sky-500 to-fuchsia-500 text-neutral-950 shadow-lg shadow-cyan-500/25 hover:shadow-cyan-500/40 hover:scale-105 active:scale-95 transition-all"
          title={isPlaying ? t.pause : t.play}
        >
          {isPlaying ? (
            <Pause className="w-6 h-6 fill-current" />
          ) : (
            <Play className="w-6 h-6 fill-current translate-x-0.5" />
          )}
        </button>

        {/* Volume Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleToggleMute}
            className="p-2 rounded-xl bg-neutral-800/60 border border-neutral-700 text-neutral-300 hover:text-white transition-all"
            title="Mute / Unmute"
          >
            {isMuted || volume === 0 ? (
              <VolumeX className="w-4 h-4 text-red-400" />
            ) : (
              <Volume2 className="w-4 h-4 text-neutral-300" />
            )}
          </button>

          <input
            type="range"
            min={0}
            max={1}
            step={0.02}
            value={isMuted ? 0 : volume}
            onChange={handleVolumeChange}
            className="w-16 sm:w-24 accent-cyan-400 h-1.5 bg-neutral-800 rounded-lg cursor-pointer"
            title={t.volume}
          />
        </div>
      </div>
    </div>
  );
};
