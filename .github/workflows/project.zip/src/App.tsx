import React, { useState, useRef, useEffect, useCallback } from 'react';
import { VisualizerCanvas, VisualizerCanvasHandle } from './components/VisualizerCanvas';
import { AudioPlayerControls } from './components/AudioPlayerControls';
import { ControlsPanel } from './components/ControlsPanel';
import { Header } from './components/Header';
import { MediaUploadHub } from './components/MediaUploadHub';
import { DirectDownloadBar } from './components/DirectDownloadBar';
import { ProfessionalExportStudio, VideoExportOptions } from './components/ProfessionalExportStudio';
import {
  WaveformConfig,
  BackgroundConfig,
  CenterArtConfig,
  TextOverlayConfig,
  EffectsConfig,
  AspectRatioType,
  AudioTrackInfo,
  VisualizerPreset,
} from './types';
import { VISUALIZER_PRESETS } from './utils/presets';
import { audioEngine } from './utils/audioEngine';
import confetti from 'canvas-confetti';
import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

// Converts a data URL or Blob into a base64 string (without the data: prefix)
const toBase64 = (input: string | Blob): Promise<string> =>
  new Promise((resolve, reject) => {
    if (typeof input === 'string') {
      resolve(input.split(',')[1] || input);
      return;
    }
    const reader = new FileReader();
    reader.onloadend = () => resolve((reader.result as string).split(',')[1]);
    reader.onerror = reject;
    reader.readAsDataURL(input);
  });

// Saves a file on-device. On Android/iOS apps (Capacitor), writes to app storage
// then opens the native Share sheet so the user can save it to Gallery/Downloads.
// On regular web browsers, falls back to a normal download link.
const saveFile = async (data: string | Blob, filename: string, mimeType: string) => {
  if (Capacitor.isNativePlatform()) {
    try {
      const base64Data = await toBase64(data);
      const result = await Filesystem.writeFile({
        path: filename,
        data: base64Data,
        directory: Directory.Cache,
      });
      await Share.share({
        title: filename,
        url: result.uri,
        dialogTitle: 'შეინახეთ ან გააზიარეთ',
      });
      return;
    } catch (e) {
      console.error('Native save failed, falling back to browser download', e);
    }
  }

  // Web fallback
  const url = typeof data === 'string' ? data : URL.createObjectURL(data);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  if (typeof data !== 'string') URL.revokeObjectURL(url);
};

export default function App() {
  const [lang, setLang] = useState<'en' | 'ka'>('ka'); // Georgian support by default based on prompt
  const initialPreset = VISUALIZER_PRESETS[0];

  const [currentPresetId, setCurrentPresetId] = useState<string>(initialPreset.id);
  const [aspectRatio, setAspectRatio] = useState<AspectRatioType>('16:9');

  // Core configurations
  const [waveform, setWaveform] = useState<WaveformConfig>({
    mode: initialPreset.waveform.mode || 'circular-bars',
    barCount: initialPreset.waveform.barCount || 96,
    barWidth: initialPreset.waveform.barWidth || 5,
    barGap: initialPreset.waveform.barGap || 3,
    barRadius: initialPreset.waveform.barRadius || 4,
    mirror: initialPreset.waveform.mirror || false,
    smoothing: initialPreset.waveform.smoothing || 0.8,
    sensitivity: initialPreset.waveform.sensitivity || 1.4,
    heightScale: initialPreset.waveform.heightScale || 1.2,
    glowIntensity: initialPreset.waveform.glowIntensity || 22,
    colorPreset: initialPreset.waveform.colorPreset || 'cyberpunk',
    customColors: ['#06b6d4', '#ec4899', '#f43f5e'],
    gradientType: 'frequency',
    positionY: initialPreset.waveform.positionY || 0.5,
    radius: initialPreset.waveform.radius || 0.22,
    lineThickness: initialPreset.waveform.lineThickness || 4,
    fillWave: initialPreset.waveform.fillWave || true,
  });

  const [background, setBackground] = useState<BackgroundConfig>({
    type: initialPreset.background.type || 'image',
    imageUrl: initialPreset.background.imageUrl || '',
    imageFit: 'cover',
    blur: initialPreset.background.blur ?? 8,
    dim: initialPreset.background.dim ?? 0.45,
    pulseWithBass: initialPreset.background.pulseWithBass ?? true,
    pulseStrength: initialPreset.background.pulseStrength ?? 0.08,
    solidColor: '#050b14',
    gradientColors: ['#0f172a', '#020617'],
    gradientAngle: 135,
  });

  const [centerArt, setCenterArt] = useState<CenterArtConfig>({
    shape: initialPreset.centerArt.shape || 'circle',
    imageUrl: initialPreset.centerArt.imageUrl || '',
    size: initialPreset.centerArt.size ?? 0.28,
    borderWidth: initialPreset.centerArt.borderWidth ?? 3,
    borderColor: initialPreset.centerArt.borderColor || '#06b6d4',
    rotationSpeed: initialPreset.centerArt.rotationSpeed ?? 0.6,
    spinWithAudio: initialPreset.centerArt.spinWithAudio ?? true,
    pulseScale: initialPreset.centerArt.pulseScale ?? 0.08,
  });

  const [textOverlay, setTextOverlay] = useState<TextOverlayConfig>({
    enabled: initialPreset.textOverlay.enabled ?? true,
    title: initialPreset.textOverlay.title || 'GO BEYOND',
    artist: initialPreset.textOverlay.artist || 'SONNA RELE',
    subtext: initialPreset.textOverlay.subtext || 'HONOR BRAND SONG',
    fontFamily: initialPreset.textOverlay.fontFamily || 'Outfit',
    titleSize: initialPreset.textOverlay.titleSize ?? 36,
    artistSize: initialPreset.textOverlay.artistSize ?? 18,
    textColor: initialPreset.textOverlay.textColor || '#ffffff',
    accentColor: initialPreset.textOverlay.accentColor || '#06b6d4',
    alignment: initialPreset.textOverlay.alignment || 'center',
    positionY: initialPreset.textOverlay.positionY ?? 84,
    showTimestamp: initialPreset.textOverlay.showTimestamp ?? false,
    showWatermark: false,
    watermarkText: '',
    dropShadow: initialPreset.textOverlay.dropShadow ?? true,
  });

  const [effects, setEffects] = useState<EffectsConfig>({
    particlesEnabled: initialPreset.effects.particlesEnabled ?? true,
    particleCount: initialPreset.effects.particleCount ?? 60,
    particleSpeed: initialPreset.effects.particleSpeed ?? 1.2,
    particleType: initialPreset.effects.particleType || 'stars',
    bassShockwave: initialPreset.effects.bassShockwave ?? true,
    chromaticAberration: initialPreset.effects.chromaticAberration ?? false,
    scanlines: initialPreset.effects.scanlines ?? false,
    vignette: initialPreset.effects.vignette ?? true,
    vignetteStrength: initialPreset.effects.vignetteStrength ?? 0.5,
    beatFlash: initialPreset.effects.beatFlash ?? true,
  });

  // Audio Playback states
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(210);
  const [isMicActive, setIsMicActive] = useState<boolean>(false);
  const [currentTrack, setCurrentTrack] = useState<AudioTrackInfo>({
    id: 'synth-gobeyond',
    title: 'GO BEYOND',
    artist: 'SONNA RELE (HONOR BRAND SONG)',
    source: 'synth',
    duration: 210,
  });

  // Recording State
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [recordingProgress, setRecordingProgress] = useState<number>(0);
  const visualizerRef = useRef<VisualizerCanvasHandle | null>(null);

  // Initialize synth beat automatically on load so user experiences instant audio-visuals
  useEffect(() => {
    audioEngine.onTimeUpdate = (cur, dur) => {
      setCurrentTime(cur);
      setDuration(dur);
    };

    audioEngine.onPlayStateChange = (playing) => {
      setIsPlaying(playing);
      setIsMicActive(audioEngine.isMicActive);
    };

    // Ready audio event listeners - do NOT auto-play on initial load
    // User can click Play or upload their custom song
    return () => {
      audioEngine.stopSynth();
      audioEngine.stopMic();
    };
  }, []);

  const handlePlayToggle = () => {
    if (isPlaying) {
      audioEngine.pause();
    } else {
      if (currentTrack.source === 'synth') {
        const genre = currentTrack.id.replace('synth-', '') as any;
        audioEngine.startSynthBeat(genre || 'synthwave');
      } else {
        audioEngine.play();
      }
    }
  };

  const handleSelectPreset = (preset: VisualizerPreset) => {
    setCurrentPresetId(preset.id);
    if (preset.waveform) setWaveform((prev) => ({ ...prev, ...preset.waveform }));
    if (preset.background) setBackground((prev) => ({ ...prev, ...preset.background }));
    if (preset.centerArt) setCenterArt((prev) => ({ ...prev, ...preset.centerArt }));
    if (preset.textOverlay) setTextOverlay((prev) => ({ ...prev, ...preset.textOverlay }));
    if (preset.effects) setEffects((prev) => ({ ...prev, ...preset.effects }));
  };

  // Snapshot capture with 4K scaling support
  const handleCaptureSnapshot = (waveformOnly = false, resolutionScale = 1) => {
    if (!visualizerRef.current) return;
    const dataUrl = visualizerRef.current.captureSnapshot(waveformOnly, resolutionScale);
    if (!dataUrl) return;

    const safeTitle = (currentTrack.title || 'waveform')
      .toLowerCase()
      .replace(/[^a-z0-9_-]/gi, '_');

    const filename = waveformOnly
      ? `${safeTitle}-waveform-transparent-${Date.now()}.png`
      : `${safeTitle}-art-${aspectRatio}-${Date.now()}.png`;
    saveFile(dataUrl, filename, 'image/png');
    confetti({ particleCount: 60, spread: 70 });
  };

  // Video recording with quality options
  const handleStartVideoRecording = async (options?: VideoExportOptions) => {
    if (!visualizerRef.current) return;
    setRecordingProgress(0);
    setIsRecording(true);
    await visualizerRef.current.startVideoRecording((sec) => {
      setRecordingProgress(sec);
    }, options);
  };

  const handleStopVideoRecording = async () => {
    if (!visualizerRef.current) return;
    const blob = await visualizerRef.current.stopVideoRecording();
    setIsRecording(false);
    if (blob) {
      const safeTitle = (currentTrack.title || 'waveform-visualizer')
        .toLowerCase()
        .replace(/[^a-z0-9_-]/gi, '_');
      const isMp4 = blob.type.includes('mp4');
      const ext = isMp4 ? 'mp4' : 'webm';
      const filename = `${safeTitle}-${aspectRatio}-master-${Date.now()}.${ext}`;

      saveFile(blob, filename, blob.type || 'video/webm');
      confetti({ particleCount: 120, spread: 100, origin: { y: 0.6 } });
    }
  };

  // Audio upload handler
  const handleUploadAudioFile = async (file: File) => {
    if (!file) return;
    try {
      const res = await audioEngine.loadAudioFile(file);
      const cleanedTitle = file.name.replace(/\.[^/.]+$/, '').replace(/^[0-9\s._-]+/, '');
      const newTrack: AudioTrackInfo = {
        id: 'uploaded-' + Date.now(),
        title: cleanedTitle || file.name,
        artist: 'Master Audio Track',
        source: 'upload',
        duration: res.duration || 180,
      };
      setCurrentTrack(newTrack);
      setTextOverlay((prev) => ({
        ...prev,
        title: cleanedTitle.toUpperCase(),
        artist: 'SONNA RELE (HONOR BRAND SONG)',
      }));
      audioEngine.play();
      confetti({ particleCount: 60, spread: 70 });
    } catch (e) {
      console.error(e);
    }
  };

  // Image upload handler (sets background and optionally cover)
  const handleUploadImageFile = (file: File) => {
    if (!file) return;
    const url = URL.createObjectURL(file);
    setBackground((prev) => ({
      ...prev,
      type: 'image',
      imageUrl: url,
    }));
    confetti({ particleCount: 50, spread: 60 });
  };

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Sticky Header */}
      <Header
        currentPresetId={currentPresetId}
        onSelectPreset={handleSelectPreset}
        aspectRatio={aspectRatio}
        onSelectAspectRatio={setAspectRatio}
        onCaptureSnapshot={() => handleCaptureSnapshot(false)}
        onRecordVideo={isRecording ? handleStopVideoRecording : handleStartVideoRecording}
        isRecording={isRecording}
        lang={lang}
        onToggleLang={() => setLang((prev) => (prev === 'ka' ? 'en' : 'ka'))}
        onQuickUploadMusic={handleUploadAudioFile}
        onQuickUploadImage={handleUploadImageFile}
      />

      {/* Main Workspace Layout */}
      <main className="flex-1 w-full max-w-7xl mx-auto p-3 sm:p-6 flex flex-col gap-6">
        {/* Prominent Media Upload Hub for Custom Music & Images */}
        <MediaUploadHub
          onAudioUploaded={(track) => {
            setCurrentTrack(track);
          }}
          currentTrack={currentTrack}
          background={background}
          onBackgroundChange={(bg) => setBackground((prev) => ({ ...prev, ...bg }))}
          centerArt={centerArt}
          onCenterArtChange={(art) => setCenterArt((prev) => ({ ...prev, ...art }))}
          onTextOverlayChange={(txt) => setTextOverlay((prev) => ({ ...prev, ...txt }))}
          lang={lang}
        />

        {/* 1-Click Direct Download Bar */}
        <DirectDownloadBar
          onDownloadSnapshot={() => handleCaptureSnapshot(false)}
          onDownloadTransparentPng={() => handleCaptureSnapshot(true)}
          onStartVideoRecording={handleStartVideoRecording}
          onStopVideoRecording={handleStopVideoRecording}
          isRecording={isRecording}
          recordingProgress={recordingProgress}
          lang={lang}
        />

        {/* Top Grid: Canvas Stage + Customization Control Panel */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left Column: Visualizer Stage Preview */}
          <div className="lg:col-span-7 xl:col-span-7 flex flex-col gap-4">
            <VisualizerCanvas
              ref={visualizerRef}
              waveform={waveform}
              background={background}
              centerArt={centerArt}
              textOverlay={textOverlay}
              effects={effects}
              aspectRatio={aspectRatio}
              currentTime={currentTime}
              duration={duration}
              isPlaying={isPlaying}
              onCanvasClick={handlePlayToggle}
              onDropAudio={handleUploadAudioFile}
              onDropImage={handleUploadImageFile}
              onDirectDownloadPng={() => handleCaptureSnapshot(false)}
              onDirectRecordVideo={isRecording ? handleStopVideoRecording : handleStartVideoRecording}
              lang={lang}
            />

            {/* Audio Player Controls */}
            <AudioPlayerControls
              isPlaying={isPlaying}
              currentTime={currentTime}
              duration={duration}
              currentTrack={currentTrack}
              isMicActive={isMicActive}
              onTrackChange={(track) => {
                setCurrentTrack(track);
                if (track.source === 'upload' && track.title) {
                  setTextOverlay((prev) => ({
                    ...prev,
                    title: track.title,
                    artist: 'CUSTOM AUDIO',
                  }));
                }
              }}
              onPlayToggle={handlePlayToggle}
              lang={lang}
            />
          </div>

          {/* Right Column: Customization Studio Panel */}
          <div className="lg:col-span-5 xl:col-span-5 flex flex-col gap-4">
            <ControlsPanel
              waveform={waveform}
              setWaveform={setWaveform}
              background={background}
              setBackground={setBackground}
              centerArt={centerArt}
              setCenterArt={setCenterArt}
              textOverlay={textOverlay}
              setTextOverlay={setTextOverlay}
              effects={effects}
              setEffects={setEffects}
              onCaptureSnapshot={handleCaptureSnapshot}
              onStartVideoRecording={handleStartVideoRecording}
              onStopVideoRecording={handleStopVideoRecording}
              isRecording={isRecording}
              recordingProgress={recordingProgress}
              lang={lang}
            />
          </div>
        </div>

        {/* Master Professional Video Export Studio (Real Video Editor Mode) */}
        <section id="pro-video-export-studio">
          <ProfessionalExportStudio
            onStartRecording={handleStartVideoRecording}
            onStopRecording={handleStopVideoRecording}
            isRecording={isRecording}
            recordingProgress={recordingProgress}
            onCaptureSnapshot={handleCaptureSnapshot}
            aspectRatio={aspectRatio}
            duration={duration}
            lang={lang}
          />
        </section>
      </main>

      {/* Subtle Studio Footer */}
      <footer className="w-full py-4 border-t border-neutral-900 text-center text-xs text-neutral-500">
        <p>
          Waveform Generator & Audio Visualizer Studio • 60 FPS Canvas Web Audio Engine • Export WebM / PNG
        </p>
      </footer>
    </div>
  );
}
