export type VisualizerMode =
  | 'circular-bars'
  | 'neon-wave'
  | 'spectrum-bars'
  | 'dual-mirror'
  | 'particle-vortex'
  | 'cyber-ring'
  | 'vinyl-disk'
  | 'matrix-blocks'
  | 'smooth-blob'
  | 'linear-oscilloscope'
  | 'polygon-morph'
  | 'starburst-rays'
  | 'ekg-pulse'
  | 'galaxy-spiral';

export type AspectRatioType = '16:9' | '9:16' | '1:1' | '4:3';

export type CenterArtShape = 'circle' | 'square' | 'rounded' | 'vinyl' | 'none';

export type ColorPresetId =
  | 'cyberpunk'
  | 'sunset'
  | 'emerald'
  | 'electric-blue'
  | 'vaporwave'
  | 'golden-hour'
  | 'fire-red'
  | 'pure-neon'
  | 'monochrome'
  | 'custom';

export interface ColorPreset {
  id: ColorPresetId;
  name: string;
  colors: string[];
  glowColor: string;
}

export interface BackgroundConfig {
  type: 'image' | 'solid' | 'gradient';
  imageUrl: string;
  imageFit: 'cover' | 'contain';
  blur: number; // 0 to 30
  dim: number; // 0 to 1 (darkness overlay)
  pulseWithBass: boolean;
  pulseStrength: number; // 0 to 1
  solidColor: string;
  gradientColors: [string, string];
  gradientAngle: number;
}

export interface CenterArtConfig {
  shape: CenterArtShape;
  imageUrl: string;
  size: number; // percentage of canvas min dimension (e.g., 0.2 to 0.5)
  borderWidth: number;
  borderColor: string;
  rotationSpeed: number; // 0 to 5
  spinWithAudio: boolean;
  pulseScale: number; // 0 to 0.3
}

export interface WaveformConfig {
  mode: VisualizerMode;
  barCount: number; // 32, 64, 128, 256
  barWidth: number; // 1 to 20
  barGap: number; // 0 to 10
  barRadius: number; // 0 to 20
  mirror: boolean;
  smoothing: number; // 0.1 to 0.95
  sensitivity: number; // 0.5 to 3.0
  heightScale: number; // 0.5 to 2.5
  glowIntensity: number; // 0 to 40
  colorPreset: ColorPresetId;
  customColors: string[];
  gradientType: 'linear' | 'radial' | 'frequency';
  positionY: number; // 0.1 to 0.9 (vertical center offset)
  radius: number; // For circular modes (0.1 to 0.5)
  lineThickness: number; // For wave modes
  fillWave: boolean;
}

export interface TextOverlayConfig {
  enabled: boolean;
  title: string;
  artist: string;
  subtext: string;
  fontFamily: 'Outfit' | 'Plus Jakarta Sans' | 'Syne' | 'JetBrains Mono' | 'Georgia';
  titleSize: number; // 16 to 72
  artistSize: number; // 12 to 48
  textColor: string;
  accentColor: string;
  alignment: 'center' | 'left' | 'right';
  positionY: number; // percentage 0 to 100
  showTimestamp: boolean;
  showWatermark: boolean;
  watermarkText: string;
  dropShadow: boolean;
}

export interface EffectsConfig {
  particlesEnabled: boolean;
  particleCount: number; // 20 to 200
  particleSpeed: number; // 0.5 to 5
  particleType: 'stars' | 'bubbles' | 'dust' | 'fireflies';
  bassShockwave: boolean;
  chromaticAberration: boolean;
  scanlines: boolean;
  vignette: boolean;
  vignetteStrength: number; // 0 to 1
  beatFlash: boolean;
}

export interface VisualizerPreset {
  id: string;
  name: string;
  nameKa?: string;
  description: string;
  waveform: Partial<WaveformConfig>;
  background: Partial<BackgroundConfig>;
  centerArt: Partial<CenterArtConfig>;
  textOverlay: Partial<TextOverlayConfig>;
  effects: Partial<EffectsConfig>;
  recommendedTrack?: string;
}

export interface AudioTrackInfo {
  id: string;
  title: string;
  artist: string;
  source: 'preset' | 'synth' | 'upload' | 'mic';
  url?: string;
  duration: number;
}
