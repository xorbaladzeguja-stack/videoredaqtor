// Web Audio API and Analysis Engine

export class AudioEngine {
  private ctx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private gainNode: GainNode | null = null;
  private audioElement: HTMLAudioElement | null = null;
  private sourceNode: MediaElementAudioSourceNode | null = null;
  private micStream: MediaStream | null = null;
  private micSource: MediaStreamAudioSourceNode | null = null;
  private synthInterval: number | null = null;
  private synthNodes: (AudioNode | { stop: () => void })[] = [];
  private isSynthPlaying: boolean = false;
  private synthBpm: number = 124;
  private synthStep: number = 0;
  private synthScale = [130.81, 146.83, 155.56, 174.61, 196.0, 207.65, 233.08, 261.63]; // C minor / Synthwave
  
  public isMicActive: boolean = false;
  public isPlaying: boolean = false;
  public currentTime: number = 0;
  public duration: number = 0;
  public onTimeUpdate?: (current: number, duration: number) => void;
  public onPlayStateChange?: (playing: boolean) => void;
  public onTrackEnded?: () => void;

  constructor() {
    // Lazy init context on first user gesture
  }

  public getContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 1024;
      this.analyser.smoothingTimeConstant = 0.8;
      this.gainNode = this.ctx.createGain();
      this.gainNode.gain.value = 0.9;
      this.gainNode.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);
    }
    if (this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
    return this.ctx;
  }

  public getAnalyser(): AnalyserNode | null {
    if (!this.analyser) {
      this.getContext();
    }
    return this.analyser;
  }

  public setSmoothing(val: number) {
    if (this.analyser) {
      this.analyser.smoothingTimeConstant = Math.max(0, Math.min(0.99, val));
    }
  }

  public setVolume(val: number) {
    if (this.gainNode) {
      this.gainNode.gain.value = Math.max(0, Math.min(1, val));
    }
    if (this.audioElement) {
      this.audioElement.volume = Math.max(0, Math.min(1, val));
    }
  }

  public async loadAudioFile(file: File | Blob | string): Promise<{ duration: number; name: string }> {
    this.stopSynth();
    this.stopMic();
    const ctx = this.getContext();

    if (!this.audioElement) {
      this.audioElement = new Audio();
      this.audioElement.crossOrigin = 'anonymous';
      this.audioElement.preload = 'auto';

      this.sourceNode = ctx.createMediaElementSource(this.audioElement);
      if (this.gainNode) {
        this.sourceNode.connect(this.gainNode);
      }

      this.audioElement.addEventListener('timeupdate', () => {
        if (this.audioElement) {
          this.currentTime = this.audioElement.currentTime;
          this.duration = this.audioElement.duration || 0;
          this.onTimeUpdate?.(this.currentTime, this.duration);
        }
      });

      this.audioElement.addEventListener('ended', () => {
        this.isPlaying = false;
        this.onPlayStateChange?.(false);
        this.onTrackEnded?.();
      });

      this.audioElement.addEventListener('play', () => {
        this.isPlaying = true;
        this.onPlayStateChange?.(true);
      });

      this.audioElement.addEventListener('pause', () => {
        this.isPlaying = false;
        this.onPlayStateChange?.(false);
      });
    }

    let url: string;
    let name = 'Audio Track';

    if (typeof file === 'string') {
      url = file;
      name = file.split('/').pop() || 'Preset Track';
    } else {
      url = URL.createObjectURL(file);
      name = (file as File).name || 'Uploaded Track';
    }

    this.audioElement.src = url;
    
    return new Promise((resolve) => {
      if (!this.audioElement) return resolve({ duration: 0, name });
      
      const onLoaded = () => {
        this.audioElement?.removeEventListener('loadedmetadata', onLoaded);
        this.duration = this.audioElement?.duration || 0;
        this.currentTime = 0;
        resolve({ duration: this.duration, name });
      };

      this.audioElement.addEventListener('loadedmetadata', onLoaded);
      // Fallback
      setTimeout(() => {
        resolve({ duration: this.audioElement?.duration || 180, name });
      }, 1000);
    });
  }

  public async play() {
    this.getContext();
    if (this.isSynthPlaying) {
      this.isPlaying = true;
      this.onPlayStateChange?.(true);
      return;
    }
    if (this.audioElement && this.audioElement.src) {
      try {
        await this.audioElement.play();
        this.isPlaying = true;
        this.onPlayStateChange?.(true);
      } catch (err) {
        console.warn('Audio play error:', err);
      }
    }
  }

  public pause() {
    if (this.isSynthPlaying) {
      this.stopSynth();
      this.isPlaying = false;
      this.onPlayStateChange?.(false);
      return;
    }
    if (this.audioElement) {
      this.audioElement.pause();
      this.isPlaying = false;
      this.onPlayStateChange?.(false);
    }
  }

  public togglePlay() {
    if (this.isPlaying) {
      this.pause();
    } else {
      this.play();
    }
  }

  public seek(seconds: number) {
    if (this.audioElement && !isNaN(seconds)) {
      this.audioElement.currentTime = Math.max(0, Math.min(this.duration, seconds));
      this.currentTime = this.audioElement.currentTime;
      this.onTimeUpdate?.(this.currentTime, this.duration);
    }
  }

  public setLoop(loop: boolean) {
    if (this.audioElement) {
      this.audioElement.loop = loop;
    }
  }

  // --- Real-time Synthesizer Beat Generator (Procedural Audio) ---
  public startSynthBeat(genre: 'gobeyond' | 'synthwave' | 'cyberpunk' | 'lofi' | 'ambient' = 'gobeyond') {
    this.stopMic();
    if (this.audioElement) {
      this.audioElement.pause();
    }

    const ctx = this.getContext();
    this.isSynthPlaying = true;
    this.isPlaying = true;
    this.onPlayStateChange?.(true);
    this.synthStep = 0;
    this.duration = 210; // 3.5 min virtual loop

    if (this.synthInterval) {
      window.clearInterval(this.synthInterval);
    }

    if (genre === 'gobeyond') {
      this.synthBpm = 126; // Energetic pop anthem tempo
      // A major / F# minor uplifting anthem scale for "Go Beyond"
      this.synthScale = [220.0, 246.94, 277.18, 293.66, 329.63, 369.99, 415.3, 440.0];
    } else if (genre === 'synthwave') {
      this.synthBpm = 124;
      this.synthScale = [130.81, 146.83, 155.56, 174.61, 196.0, 207.65, 233.08, 261.63];
    } else if (genre === 'cyberpunk') {
      this.synthBpm = 138;
      this.synthScale = [130.81, 146.83, 155.56, 174.61, 196.0, 207.65, 233.08, 261.63];
    } else if (genre === 'lofi') {
      this.synthBpm = 84;
      this.synthScale = [130.81, 146.83, 155.56, 174.61, 196.0, 207.65, 233.08, 261.63];
    } else {
      this.synthBpm = 100;
      this.synthScale = [130.81, 146.83, 155.56, 174.61, 196.0, 207.65, 233.08, 261.63];
    }

    const stepTimeMs = (60 / this.synthBpm / 4) * 1000; // 16th notes

    const triggerStep = () => {
      if (!this.isSynthPlaying || !this.gainNode) return;
      const t = ctx.currentTime;
      const step = this.synthStep % 16;
      this.currentTime = (this.synthStep * (60 / this.synthBpm / 4)) % this.duration;
      this.onTimeUpdate?.(this.currentTime, this.duration);

      if (genre === 'gobeyond') {
        // Go Beyond Anthem arrangement
        // 1. Kick on 0, 4, 8, 12 + dynamic pre-drop kicks
        if (step === 0 || step === 4 || step === 8 || step === 12) {
          this.playKick(ctx, t);
        }
        // 2. Powerful stadium clap / snare on 4, 12 + upbeat 14
        if (step === 4 || step === 12) {
          this.playSnare(ctx, t);
        }
        // 3. Shimmering high-energy hi-hats
        this.playHiHat(ctx, t, step % 4 === 2);

        // 4. Anthem uplifting Bass line (A - F#m - D - E progression)
        const chordPhase = Math.floor((this.synthStep / 16) % 4);
        const anthemBassRoots = [0, 5, 3, 4]; // A, F#, D, E
        const root = anthemBassRoots[chordPhase];
        const bassNote = this.synthScale[root] * 0.5;
        this.playBass(ctx, t, bassNote, (stepTimeMs * 1.8) / 1000);

        // 5. "Go Beyond" Anthem Hook Lead Melody
        // Notes corresponding to uplifting vocal hook (E - F# - A - B - C# - A)
        const hookNotes = [
          [4, 5, 7, 7, 5, 4, 2, 4, 5, 7, 7, 5, 4, 2, 0, 2], // Hook Part A
          [4, 5, 7, 7, 5, 4, 2, 4, 5, 7, 8, 7, 5, 4, 2, 4], // Hook Part B
          [7, 7, 5, 7, 7, 5, 4, 2, 4, 5, 7, 7, 5, 4, 2, 0], // Hook Peak
          [0, 2, 4, 5, 7, 5, 4, 2, 0, 2, 4, 7, 5, 4, 2, 0], // Anthem Resolve
        ][chordPhase];

        const hookNoteIndex = hookNotes[step] % this.synthScale.length;
        const leadFreq = this.synthScale[hookNoteIndex] * 2.0;
        this.playLead(ctx, t, leadFreq, (stepTimeMs * 1.2) / 1000);
      } else {
        // Standard electronic beat
        if (step === 0 || step === 4 || step === 8 || step === 12) {
          this.playKick(ctx, t);
        }
        if (step === 4 || step === 12) {
          this.playSnare(ctx, t);
        }
        if (step % 2 === 0 || step % 4 === 2) {
          this.playHiHat(ctx, t, step % 4 === 2);
        }
        const bassNoteIndex = [0, 0, 3, 0, 4, 0, 2, 5, 0, 0, 3, 0, 6, 0, 5, 2][step];
        const bassFreq = this.synthScale[bassNoteIndex] * 0.5;
        this.playBass(ctx, t, bassFreq, stepTimeMs / 1000);

        if (step % 2 === 0) {
          const leadIdx = (step + (Math.floor(this.synthStep / 16) % 4)) % this.synthScale.length;
          const leadFreq = this.synthScale[leadIdx] * (genre === 'ambient' ? 1.0 : 2.0);
          this.playLead(ctx, t, leadFreq, (stepTimeMs * 1.5) / 1000);
        }
      }

      this.synthStep++;
    };

    triggerStep();
    this.synthInterval = window.setInterval(triggerStep, stepTimeMs);
  }

  private playKick(ctx: AudioContext, t: number) {
    if (!this.gainNode) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(150, t);
    osc.frequency.exponentialRampToValueAtTime(38, t + 0.12);
    gain.gain.setValueAtTime(1.0, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);
    osc.connect(gain);
    gain.connect(this.gainNode);
    osc.start(t);
    osc.stop(t + 0.3);
  }

  private playSnare(ctx: AudioContext, t: number) {
    if (!this.gainNode) return;
    // Noise buffer
    const bufferSize = ctx.sampleRate * 0.15;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.04));
    }
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.value = 1000;

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(0.6, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + 0.15);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.gainNode);
    noise.start(t);
    noise.stop(t + 0.16);

    // Snare tone
    const osc = ctx.createOscillator();
    const oscGain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(220, t);
    osc.frequency.exponentialRampToValueAtTime(90, t + 0.08);
    oscGain.gain.setValueAtTime(0.5, t);
    oscGain.gain.exponentialRampToValueAtTime(0.01, t + 0.1);
    osc.connect(oscGain);
    oscGain.connect(this.gainNode);
    osc.start(t);
    osc.stop(t + 0.11);
  }

  private playHiHat(ctx: AudioContext, t: number, open: boolean = false) {
    if (!this.gainNode) return;
    const dur = open ? 0.08 : 0.03;
    const bufferSize = ctx.sampleRate * dur;
    const buffer = ctx.createBuffer(1, bufferSize, ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = (Math.random() * 2 - 1) * Math.exp(-i / (ctx.sampleRate * 0.015));
    }
    const noise = ctx.createBufferSource();
    noise.buffer = buffer;
    const filter = ctx.createBiquadFilter();
    filter.type = 'highpass';
    filter.frequency.value = 7000;
    const gain = ctx.createGain();
    gain.gain.setValueAtTime(open ? 0.35 : 0.2, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + dur);
    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.gainNode);
    noise.start(t);
    noise.stop(t + dur + 0.01);
  }

  private playBass(ctx: AudioContext, t: number, freq: number, dur: number) {
    if (!this.gainNode) return;
    const osc = ctx.createOscillator();
    const filter = ctx.createBiquadFilter();
    const gain = ctx.createGain();

    osc.type = 'sawtooth';
    osc.frequency.setValueAtTime(freq, t);

    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(600, t);
    filter.frequency.exponentialRampToValueAtTime(150, t + dur);
    filter.Q.value = 5;

    gain.gain.setValueAtTime(0.5, t);
    gain.gain.exponentialRampToValueAtTime(0.01, t + dur);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.gainNode);

    osc.start(t);
    osc.stop(t + dur + 0.02);
  }

  private playLead(ctx: AudioContext, t: number, freq: number, dur: number) {
    if (!this.gainNode) return;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    const filter = ctx.createBiquadFilter();

    osc.type = 'square';
    osc.frequency.setValueAtTime(freq, t);

    filter.type = 'lowpass';
    filter.frequency.value = 2200;

    gain.gain.setValueAtTime(0.18, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + dur);

    osc.connect(filter);
    filter.connect(gain);
    gain.connect(this.gainNode);

    osc.start(t);
    osc.stop(t + dur + 0.01);
  }

  public stopSynth() {
    this.isSynthPlaying = false;
    if (this.synthInterval) {
      window.clearInterval(this.synthInterval);
      this.synthInterval = null;
    }
  }

  // --- Microphone Live Stream ---
  public async startMic(): Promise<boolean> {
    try {
      this.stopSynth();
      if (this.audioElement) {
        this.audioElement.pause();
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
      const ctx = this.getContext();
      
      this.micStream = stream;
      this.micSource = ctx.createMediaStreamSource(stream);
      
      // Connect to analyser only (DO NOT connect mic to speaker destination to prevent feedback scream!)
      if (this.analyser) {
        this.micSource.connect(this.analyser);
      }
      
      this.isMicActive = true;
      this.isPlaying = true;
      this.onPlayStateChange?.(true);
      return true;
    } catch (err) {
      console.error('Failed to get microphone input:', err);
      this.isMicActive = false;
      return false;
    }
  }

  public stopMic() {
    if (this.micStream) {
      this.micStream.getTracks().forEach((track) => track.stop());
      this.micStream = null;
    }
    if (this.micSource) {
      try {
        this.micSource.disconnect();
      } catch {}
      this.micSource = null;
    }
    this.isMicActive = false;
  }

  // --- Frequency & Waveform Data Extraction ---
  public getFrequencyData(freqData: Uint8Array): void {
    if (this.analyser) {
      this.analyser.getByteFrequencyData(freqData);
    }
  }

  public getTimeDomainData(timeData: Uint8Array): void {
    if (this.analyser) {
      this.analyser.getByteTimeDomainData(timeData);
    }
  }

  public getEnergyMetrics(freqData: Uint8Array): {
    bass: number;
    mid: number;
    treble: number;
    overall: number;
  } {
    const len = freqData.length;
    if (len === 0) return { bass: 0, mid: 0, treble: 0, overall: 0 };

    let bassSum = 0;
    const bassCount = Math.max(1, Math.floor(len * 0.12));
    for (let i = 0; i < bassCount; i++) {
      bassSum += freqData[i];
    }

    let midSum = 0;
    const midStart = bassCount;
    const midEnd = Math.floor(len * 0.5);
    const midCount = Math.max(1, midEnd - midStart);
    for (let i = midStart; i < midEnd; i++) {
      midSum += freqData[i];
    }

    let trebleSum = 0;
    const trebleStart = midEnd;
    const trebleCount = Math.max(1, len - trebleStart);
    for (let i = trebleStart; i < len; i++) {
      trebleSum += freqData[i];
    }

    let totalSum = 0;
    for (let i = 0; i < len; i++) {
      totalSum += freqData[i];
    }

    return {
      bass: (bassSum / bassCount) / 255,
      mid: (midSum / midCount) / 255,
      treble: (trebleSum / trebleCount) / 255,
      overall: (totalSum / len) / 255,
    };
  }

  public getAudioOutputStream(): MediaStreamAudioDestinationNode | null {
    if (!this.ctx || !this.analyser) return null;
    try {
      const dest = this.ctx.createMediaStreamDestination();
      this.analyser.connect(dest);
      return dest;
    } catch {
      return null;
    }
  }
}

export const audioEngine = new AudioEngine();
