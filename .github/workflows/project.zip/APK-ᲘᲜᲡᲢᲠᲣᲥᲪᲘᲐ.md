# როგორ ავაწყოთ APK (Android აპლიკაცია)

ეს პროექტი ახლა მზადაა Capacitor-ით APK-ად გადასაქცევად. ვიდეო და ფოტოს
გადმოწერის ღილაკები აღარ იყენებენ ჩვეულებრივ ბრაუზერის "download"-ს — APK-ის
შიგნით ავტომატურად გაიხსნება Android-ის "გაზიარების" (Share) მენიუ, საიდანაც
პირდაპირ შეძლებთ ვიდეო/ფოტოს გალერეაში ("Save to Gallery"/"Files") შენახვას.
სქრინ-ჩაწერა საერთოდ არ არის საჭირო — ვიდეო თავად იწერება canvas-იდან.

## ნაბიჯები (კომპიუტერზე, სადაც Node.js დაყენებული გაქვთ)

1. გახსენით ტერმინალი პროექტის ფოლდერში და გაუშვით:
   ```
   npm install
   npx cap add android
   npm run build
   npx cap sync android
   ```

2. APK-ის ასაწყობად გახსენით `android` ფოლდერი Android Studio-ში და
   დააჭირეთ **Build → Build Bundle(s) / APK(s) → Build APK(s)**.

   ან, თუ GitHub Actions გირჩევნიათ (როგორც წინა პროექტებში), დამატებით
   Actions workflow დაგჭირდებათ Android SDK-ისთვის — ეს შემიძლია ცალკე
   მოგამზადოთ, თუ გინდათ.

## შენიშვნა

`capacitor.config.json`-ში `appId`-ია `ge.guji.waveformvisualizer` — შეგიძლიათ
შეცვალოთ თუ სხვა სახელი გინდათ.
